var sayings;
if(0)
sayings = "\
a bad beginning makes a bad ending - что посеешь,то и пожнешь^\
"+"\
after all - despite, nevertheless  - все-таки  - I knew it! After all, I was right!^\
all along - all the time  - все время, всегда  - I knew about his little secret all along.^\
";else 
sayings= "\
a bad beginning makes a bad ending - что посеешь,то и пожнешь^\
a good beginning makes a good ending - хорошее начало полдела откачало^\
a good Jack makes a good Jill - у хорошего мужа и жена хорошая^\
be made one - пожениться, повенчаться^\
be on the make - делать карьеру; заниматься исключительно с корыстью^\
believe that the moon is made of green cheese - верить всяким небылицам^\
can't make head or tail of it - ничего нельзя понять^\
enough to make a cat laugh - очень смешно; мертвого может рассмешить^\
fine feathers make fine birds - одежда красит человека^\
haste makes waste - поспешишь людей насмешишь^\
he can never resist making a joke - он не может не пошутить^\
he failed to make use of the opportunity - он не воспользовался этой возможностью^\
he is made of sterner stuff than his father - у него более решительный характер,чем у его отца^\
he made a better fist of it - дело у него пошло лучше^\
he made a blunder - он совершил большую ошибку^\
he made a great show of zeal - он делал вид,что очень старается^\
he made a poor fist of it - дело у не задалось^\
he made a thousand and one excuses - он тысячу раз извинялся^\
he makes things hum - у него работа кипит^\
he resolved upon making an early start - он решил рано отправиться в путь^\
he struggled to make himself heard - он всячески старался,чтобы его услышали^\
he was made to be an actor - он прирожденный актер^\
he will make a good musician - из него выйдет хороший музыкант^\
I am not made of salt - не сахарный,не растаю^\
I make bold to say - осмелюсь сказать^\
I make it a rule to get up early - я обычно рано встаю^\
I must make sure of a house for winter - я должен обеспечить себе жилье на зиму^\
I propose to make a journey this summer - летом я намерен попутешествовать^\
I shall make a week's stay there - я пробуду там неделю^\
it is enough to make somebody swear - этого достаточно,чтобы вывести из себя^\
it is no use making a song about it - из этого не стоит создавать истории^\
it made his hair stand on end - от этого у него волосы встали дыбом^\
it made his mouth water - у него слюнки потекли^\
it makes a vast difference - это полностью меняет дело^\
it makes all the difference in the world - это существенно меняет дело, это очень важно^\
it makes no difference - это не имеет значения; нет никакой разницы^\
it makes no odds - несущественно; не составляет никакой разницы^\
it makes no sense - в этом нет смысла^\
it makes one's blood run cold - от этого кровь стынет в жилах^\
let it make an example for him - пусть это послужит ему уроком^\
lie on the bed one has made - что посеешь,то и пожнешь^\
made of superior cloth - сделанный из сукна высшего качества^\
made to measure - сделанный на заказ; сшитый по мерке^\
made to order - сделанный на заказ^\
make a bad break - проговориться, обмолвиться; обанкротиться; сделать ошибку, сделать ложный шаг^\
make a balk of good ground - упустить удобный случай^\
make a bargain - прийти к соглашению; заключить сделку^\
make a beast of oneself - безобразно вести себя^\
make a bet - заключить пари^\
make a bolt - удрать; броситься, помчаться^\
make a bonfire of - разрушать, разрушить; уничтожать, уничтожить; сжигать (на костре)make a bungle of it - запороть; напортить^\
make a cat's-paw of a person - сделать своим орудием (кого-либо)^\
make a circuit - пойти обходным путем^\
make a clean breast of it - чистосердечно сознаться в (чем-либо)make a clean cut - резать ровно^\
make a clean sweep - избавиться, окончательно отделаться, избавляться, окончательно отделываться^\
make a clean sweep of - полностью избавиться, совершенно отделаться, подчистить под метлу^\
make a clean sweep of something - совершенно отделаться; избавиться от чего-либо^\
make a clutch at - схватить^\
to make a clutch at something - схватить что-либо^\
make a comparison - проводить сравнение^\
make a complete come-back - окончательно поправиться^\
make a convenience of somebody - злоупотреблять вниманием или дружбой кого-либо^\
make a curtsey - присесть, сделать реверанс^\
make a dash against the enemy - стремительно броситься на противника^\
make a dash for - кинуться к^\
make a dash for something - кинуться к чему-либо^\
make a day of it - весело провести день^\
make a dead set at - домогаться любви,внимания; нападать на, напасть на; подвергать резкой критике, подвергнуть резкой критике^\
make a deal - заключить сделку^\
to do a deal with somebody - заключить сделку с кем-либо^\
make a declaration - сделать заявление, заявить^\
make a detour - сделать крюк^\
make a diagnosis - поставить диагноз^\
make a diagnostic - поставить диагноз^\
make a draft on a fund - извлечь выгоду, воспользоваться, извлекать пользу (дружбой, хорошим отношением, доверием); взять часть вклада с текущего счета^\
make a dust - поднимать шум, поднять суматоху, поднять шум^\
make a fire - разжигать костер, разжечь костер^\
make a floater - попасть впросак, влипнуть^\
make a fluff - дать маху^\
make a fool - одурачить^\
make a fool of oneself - поставить себя в глупое положение, свалять дурака^\
make a fortune - разбогатеть^\
make a fresh start - начать все заново^\
make a fuss - поднимать шум, привлекать внимание; суетливо опекать, шумно опекать кого-либо^\
make a fuss about something - суетиться; волноваться попусту, раздраженно жаловаться^\
make a getaway - ускользнуть; бежать^\
make a go of it - добиться успеха, преуспеть^\
make a god - боготворить^\
make a good breakfast - хорошо позавтракать^\
make a good job of it - сделать хорошо что-либо^\
make a good name for oneself - завоевать доброе имя, завоевывать доброе имя^\
make a good shot - не ошибиться, не ошибаться; отгадать, отгадывать^\
make a good showing - производить хорошее впечатление, произвести хорошее впечатление^\
make a good thing - извлечь пользу^\
make a hash - напутать, напортить^\
make a hole in something - сильно опустошить (напр. запасы, сбережения)^\
make a house - обеспечить кворум (в палате общин)^\
make a joke - пошутить^\
make a joke of something - свести что-либо к шутке^\
make a journey - путешествовать^\
make a Judy of oneself - свалять дурака^\
make a knot - завязать узел^\
make a lane - дать дорогу^\
make a leg - расшаркиваться, расшаркаться^\
make a light meal - перекусить^\
make a list - составлять список, составить список^\
make a little money on the side - подработать немного денег на стороне, подрабатывать немного денег на стороне^\
make a lodgement - обосноваться, закрепиться^\
make a lodgment - обосноваться, закрепиться^\
make a long face - помрачнеть^\
make a long nose - показать нос^\
make a long story short - короче говоря^\
make a martyr of oneself - строить из себя мученика^\
make a match - выйти замуж; жениться^\
make a matter of conscience - поступать по совести^\
make a merit - ставить себе в заслугу something - что-либо^\
make a mess of things - напортить; провалить все дело; напутать^\
make a mistake - ошибаться, делать ошибку, сделать ошибку, ошибиться^\
make a mock of - вышучивать, вышутить^\
make a mountain out of a molehill - преувеличивать, преувеличить; делать из мухи слона, сделать из мухи слона^\
make a move - вставать из-за стола, встать из-за стола; начать действовать, начинать действовать; предпринять что-то, предпринимать действия; сделать ход, делать ход; отправляться, отправиться^\
make a muck - испортить, изгадить, портить something - что-либо^\
make a muddle - спутать, перепутать something - что-либо^\
make a mull - перепутать something - что-либо^\
make a mush - спутать, путать^\
make a mystery of - делать секрет из^\
make a neat job of it - хорошо сделать, искусно сделать что-либо^\
make a night of it - прокутить всю ночь напролет^\
make a noise about something - поднимать шум, поднять шум чего-либо^\
make a noise in the world - быть у всех на устах; производить сенсацию, произвести сенсацию^\
make a nuisance of oneself - надоедать, надоесть^\
make a parachute descent - спуститься с парашютом^\
make a parade of something - выставлять напоказ, щеголять, кичиться что-либо, чем-либо^\
make a pass - приставать, пристать; делать выпад, сделать выпад^\
make a pause - остановиться^\
make a person yawn - нагнать сон, нагнать скуку кого-либо^\
make a pig of oneself - объедаться, обжираться, объесться, обожраться^\
make a pint measure hold a quart - стараться сделать невозможное^\
make a place too hot - выкурить^\
make a point - доказать положение; считать обязательным для себя something - что-либо; делать стойку, сделать стойку^\
make a precarious living - жить случайными доходами, кое-как перебиваться^\
make a present - дарить, подарить^\
make a pretence - притворяться, притвориться^\
make a pretense - притворяться, притвориться^\
make a profit on - извлечь выгоду из^\
make a promise - обещать, пообещать^\
make a protest - заявлять протест, заявить протест^\
make a push - приложить большое усилие^\
make a racket - поднять шум, поднять скандал, поднимать шум, поднимать скандал^\
make a raid upon the enemy's camp - совершить набег на лагерь противника^\
make a raise - раздобыть, получить взаймы^\
make a reach - протянуть руку, потянуться^\
make a regular thing - регулярно заниматься чем-либо^\
make a religion - сделать культ^\
make a religion of something - считать своей священной обязанностью (что-либо)^\
make a request - сделать заявку, делать заявку; обратиться с просьбой^\
make a reservation - забронировать, бронировать^\
make a rod for one's own back - наказать самого себя, наказывать самого себя^\
make a row - протестовать; поднимать скандал,шум, поднять скандал,шум^\
make a sacrifice - приносить жертву, принести жертву^\
make a scene - устроить сцену, устраивать сцену^\
make a score off one's own bat - сделать без помощи других, сделать самостоятельно^\
make a sharp come-back - возникать с новой силой^\
make a shift - перебиваться кое-как, довольствоваться чем-либо; обходиться, обойтись; ухитряться, ухитриться^\
make a short cut - избрать кратчайший путь, избирать кратчайший путь^\
make a sight of oneself - делать из себя посмешище, сделать из себя посмешище^\
make a smart job of it - быстро,хорошо выполнить работу^\
make a snatch - пытаться схватить, попытаться схватить^\
make a snook at somebody - длинный нос, показывать длинный нос кому-либо^\
make a snoot - гримасничать^\
make a speciality - специализироваться of something - в чем-либо^\
make a spectacle of oneself - обращать на себя внимание^\
make a speech - произносить речь^\
make a splash - вызвать сенсацию^\
make a stand against - выступить против; оказывать сопротивление^\
make a stand for - выступить в защиту^\
make a start - отправиться, отправляться; начать, начинать^\
make a statement - заявлять, делать заявление, заявить, сделать заявление^\
make a stranger - холодно обходиться^\
make a study of - тщательно изучать, тщательно изучить^\
make a suggestion - вносить предложение, внести предложение; подать мысль, подавать мысль^\
make a tardy appearance - прийти с опозданием, приходить с опозданием^\
make a time of it - хорошо провести время^\
make a touch-down - совершить посадку^\
make a toy - забавляться чем-либо^\
make a virtue of necessity - из нужды делать добродетель; делать вид,что действуешь добровольно; сама захотела,когда нужда повелела^\
make a visit - навещать, посещать^\
make a volte-face - переметнуться в лагерь противника^\
make a vow - дать клятву^\
make a voyage - совершить путешествие (по морю)^\
make adjustment - приспособиться^\
make advances - идти навстречу, пойти навстречу (в чем-либо); делать авансы, делать предложения^\
make afraid - испуганный, бояться, пугать^\
make after - пускаться вслед; преследовать^\
make against - говорить не в пользу (кого-либо)^\
make ample provision for one's family - вполне обеспечить семью^\
make an apology - принести извинение, извиниться^\
make an appeal to - привлекать, действовать притягательно на (кого-либо)^\
make an appeal to somebody - привлекать кого-либо; действовать притягательно на кого-либо^\
make an appearance - показываться, появляться, показаться, появиться^\
make an ass - подшутить, поставить в глупое положение^\
make an ass of oneself - ставить себя в глупое положение, поставить себя в глупое положение; валять дурака; ставить себя в глупое положение^\
make an ass of somebody - поставить в глупое положение, подшутить над кого-либо, кем-либо^\
make an effort - сделать усилие, попытаться^\
make an emphasis on - придавать особое значение, особенно подчеркивать (что-либо)^\make an end - положить конец, уничтожить^\
make an errand - выдумать предлог чтобы уйти^\
make an error - совершить ошибку, ошибиться^\
make an exhibition of oneself - делать из себя посмешище, стать посмешищем; показывать себя с дурной стороны, вызывать осуждение, вызвать осуждение^\
make an honest woman of somebody - жениться на соблазненной девушке^\
make an impression - произвести впечатление^\
make an observation - сделать замечание, делать замечания^\
make angry - сердить, рассердить^\
make somebody angry - рассердить кого-либо^\
make approaches to - подъезжать к, стараться привлечь внимание^\
make arrangements - организовывать, организовать (что-либо); договариваться, договориться (о чем-либо)^\
make arrangements with - уславливаться с, вступать в соглашение с^\
make assurance double sure - вдвойне застраховаться; для большей верности^\
make available - предоставлять, предоставить^\
make away with - избавиться от, отделаться от (чего-либо, кого-либо); убить (кого-либо); уничтожать, уничтожить, убивать, убить, устранять, устранить^\
make away with oneself - покончить с собой, совершить самоубийство^\
make back - вернуться, возвратиться^\
make balls of - натворить дел, напутать^\
to make balls of something - привести что-либо в беспорядок^\
make believe - делать вид, притворяться, сделать вид, притвориться^\
make boards - лавировать^\
make boast of - хвастать, хвастаться (чем-либо)^\
make bold with - позволять себе вольности с^\
make both ends meet - сводить концы с концами^\
make bricks without straw - работать,не имея нужного материала, затевать безнадежное дело^\
make broad one's phylactery - выставлять напоказ свою набожность^\
make capital - нажить капитал, нажить капитал на (чем-либо)^\
to make capital out of something - нажить капитал на чем-то^\
make certain of - удостовериться в^\
make certain of your facts before you argue - проверьте ваши данные,прежде чем спорить^\
make choice of - выбирать, отбирать^\
to make choice of something - выбирать, отбирать что-либо^\
make common cause - действовать сообща^\
make common cause with - объединяться ради общего дела^\
make common cause with somebody - объединяться с кем-либо ради общего дела^\
make contact - включать ток, выключать ток^\
make conversation - вести пустой разговор^\
make difficulties - чинить препятствия, препятствовать^\
make dispositions for a campaign - готовиться к кампании^\
make doubt - не сомневаться, быть уверенным, проверить^\
make no doubt about it - не сомневайтесь в этом, будьте уверены^\
make efforts - приложить усилия^\
make efforts towards a reconciliation - стараться добиться примирения^\
make eyes - следить во^\
make eyes at somebody - делать глазки кому-либо^\
make face - корчить рожи^\
make fast - запирать, запереть (дверь); закреплять, закрепить^\
make fish of one and flesh of another - относиться к людям неровно, быть лицеприятным^\
make for - способствовать, содействовать^\
make free - освобождать^\
make free use - пользоваться без ограничений чем-либо^\
make free use of something - широко пользоваться^\
make free with - позволять себе вольности, позволять себе бесцеремонность по отношению к (кому-либо)^\
make friends - подружиться; помириться^\
make fun - высмеивать, высмеять; подсмеиваться; высмеивать^\
make game of - подшучивать, подшутить; высмеивать, высмеять^\
make good a loss - возместить убыток^\
make good cheer - пировать, угощаться^\
make good execution - перебить (противника); разгромить^\
make good one's retreat - удачно отделаться, удачно отделываться; благополучно отступить, благополучно отступать^\
make good one's running - преуспевать, преуспеть; не отставать, не отстать^\
make good resolves - быть полным добрых намерений^\
make great display of generosity - хвастаться своей щедростью^\
make great strides - делать большие успехи^\
make hard work of something - преувеличивать трудности (мероприятия и т. п.)^\
make haste - спешить, поспешить; поторапливайся; спешить, торопиться^\
make haste or else you will be late - торопитесь,иначе вы опоздаете^\
make havoc - производить беспорядок, разрушать, разрушить^\
make hay - вносить путаницу; наживаться; косить траву, сушить сено^\
make hay of something - разбить, опровергнуть (чьи-либо доводы и т. п.); перевернуть вверх дном^\
make head - продвигаться вперед^\
make head against - сопротивляться, противиться^\
make headway - преуспевать; делать успехи^\
make heavy weather - находить трудным, считать утомительным of something - что-либо^\
make inroads upon somebody's time - посягать на время кого-либо^\
make it a point of virtue - возводить в добродетель что-либо^\
make it a rule - взять за правило, брать за правило^\
make it one's business - считать своей обязанностью^\
make it plain - выявить, разъяснить, выявлять, разъяснять^\
make it snappy - быстро, живо (повелительный возглас)^\
make leeway - отклониться от намеченного пути; струсить; дрейфовать^\
make light - относиться несерьезно, относиться небрежно, не придавать значения, отнестись несерьезно, отнестись небрежно, не придать значения^\
make little of something - не принимать всерьез, не придавать значения^\
make love to - добиваться физической близости, заниматься любовью с; ухаживать за^\
make matchwood - разгромить; разбить вдребезги^\
make merry - веселиться, пировать^\
make merry over (with, about) somebody, something - потешаться над кем-либо, чем-либо^\
make mincemeat of - разбить, уничтожить (противника); превратить в котлету^\
make mischief - вредить, повредить; ссорить, сеять раздоры, поссорить, посеять раздоры^\
make money - разбогатеть; зарабатывать деньги, заработать деньги^\
make mouths - строить рожи, гримасничать^\
make much of - носиться с, носиться с (кем-либо, чем-либо); быть высокого мнения о; высоко ценить^\
make no bones about - не церемониться; не колебаться, не сомневаться^\
make no haste to do - медлить^\
make no mistake - непременно, обязательно; несомненно, бесспорно^\
make no pretence - не претендовать^\
make no pretense - не претендовать^\
make no question of - не сомневаться, вполне допускать^\
make no reckoning - не придавать значения; не принимать в расчет^\
make no reference to - не упомянуть о (чем-либо)^\
make no remark - ничего не сказать, ничего не говорить^\
make no sign - не протестовать; не подавать признаков жизни^\
make nothing - не понять, не понимать; не иметь преимуществ; не иметь претензий; пренебрегать, легко относиться, пренебречь, легко отнестись; никак не использовать^\
make odds even - устранить различия, устранять различия^\
make old bones - дожить до глубокой старости^\
make one's abode - жить (где-либо)^\
make one's adieu - прощаться^\
make one's bow - удалиться; откланяться^\
make one's bread - зарабатывать на жизнь^\
make one's choice - сделать выбор^\
make one's head sing - выдать сообщников преступления, выдавать сообщников преступления; расколоться, раскалываться^\
make one's home - поселиться^\
make one's jack - хорошо заработать^\
make one's living - зарабатывать на жизнь; зарабатывать на жизнь^\
make one's mark - сделать карьеру; приобрести известность; выдвинуться, отличиться^\
make one's moan - жаловаться^\
make one's own clothes - шить самой себе^\
make one's peace - мириться, помириться^\
make one's pile - нажить состояние^\
make one's way - сделать карьеру, завоевать положение в обществе; продвигаться, пробираться^\
make one's way by shifts - изворачиваться^\
make one's way in the world - сделать карьеру, завоевать положение в обществе^\
make one's will - сделать завещание^\
make oneself cheap - позволять вольности по отношению к себе; вести себя недостойно^\
make oneself conspicuous - обращать на себя внимание^\
make oneself master - добиться совершенства, овладеть^\
make oneself scarce - удалиться, уйти, удаляться, уходить; не попадаться на глаза, не попасться на глаза; ретироваться^\
make oneself understood - уметь объясниться^\
make or mar - либо пан либо пропал^\
make out one's case - доказать свою правоту^\
make overtures to somebody - пытаться завязать знакомство, попытаться завязать знакомство; делать авансы, сделать авансы; делать попытки к примирению, сделать попытки к примирению^\
make peace - мирить, мириться, помирить, помириться; заключать мир, заключить мир^\
make people stare - удивлять,поражать людей^\
make preparations for - готовиться к, проводить подготовку к^\
make prize of - захватить, захватывать^\
make progress - делать успехи, сделать успехи; делать успехи; развиваться^\
make provisions - предусматривать, постановлять, предусмотреть, постановить^\
make ready - приготовлять^\
make reference - ссылаться, сослаться^\
make restitution - возместить убытки, возмещать убытки^\
make rings round someone - намного опередить, намного обогнать, намного опережать, намного обгонять кого-либо; за пояс заткнуть, за пояс затыкать (кого-либо)^\
make room for - потесниться, дать место, давать место^\
make rubbings - срисовывать, делать копии, срисовать, сделать копию^\
make rules - устанавливать правила, установить правила^\
make salvage - спасать, спасти (что-либо)^\
make satisfaction - возмещать, возместить^\
make shipwreck - погибнуть, разориться, погибать, разоряться^\
make short work - быстро справиться, быстро разделаться, быстро справляться, быстро разделываться^\
make somebody gape - изумить^\
make somebody open his eyes - открыть глаза^\
make somebody sit up - расшевелить, встряхнуть, встряхивать, расшевеливать кого-либо^\
make somebody squeal - шантажировать, вымогать деньги^\
make somebody's blood boil - довести до бешенства кого-либо^\
make somebody's blood creep - приводить в содрогание (кого-либо)^\
to make somebody's blood boil - приводить кого-либо в бешенство^\
make somebody's brain reel - поразить (кого-либо)^\
make somebody's nose swell - вызывать сильную зависть, вызывать ревность, вызвать сильную зависть, вызвать ревность^\
make something grow - выращивать что-либо^\
make sport of - высмеивать, высмеять^\
make start - начинать, начать^\
make suit to - смиренно просить, смиренно попросить^\
make sure of - убедиться, удостовериться, убеждаться, удостоверяться; достать, доставать; обеспечить, обеспечивать; быть уверенным (в чем-либо)^\
make sure work with something - обеспечить свой контроль над чем-либо^\
make tea - заваривать чай, заварить чай^\
make the air blue - сквернословить, ругаться^\
make the bag - убить дичи больше,чем другие охотники^\
make the bed - стлать постель^\
make the best - использовать нечто наилучшим образом, мириться^\
make the best of a bad bargain - не падать духом в беде^\
make the best of a bad job - мужественно переносить невзгоды^\
make the best of it - мужественно переносить затруднения, мужественно переносить несчастье, не унывать в беде^\
make the best of one's way - идти как можно скорее, спешить; идти как можно скорее, спешить^\
make the best of what you have - используй лучше то,что имеешь (полный вариант этой пословицы таков: if you cannot have the best, make the best of what you have если не имеешь лучшего, используй получше то, что есть)^\
make the bull's-eye - попадать в цель, попасть в цель^\
make the feathers fly - раззадорить, стравить (противников)^\
make the fur fly - поднять бучу, затеять ссору^\
make the grade - добиться успеха; добиться своего; брать крутой подъем^\
make the land - приближаться к берегу^\
make the money fly - промотать деньги; швырять деньгами, швыряться деньгами^\
make the most of - расхваливать, преувеличивать достоинства; использовать наилучшим образом^\
make the pot boil - подрабатывать, халтурить; зарабатывать средства к жизни^\
make the running - добиться успеха, преуспевать, добиваться успеха, преуспеть; добиться хороших результатов, добиваться хороших результатов (о жокее, скаковой лошади)^\
make the tea - заваривать чай, заварить чай^\
make the train - поспеть на поезд^\
make things lively - задать жару somebody - кому-либо; доставлять неприятные минуты somebody - кому-либо^\
make things warm - досаждать кому-либо^\
make things warm for somebody - сделать невыносимым чье-либо положение^\
make time - ехать на определенной скорости; спешить,пытаясь наверстать упущенное^\
make time pass - коротать время^\
make tracks - дать тягу, улизнуть, убежать^\
make tracks for - отправиться, направить свои стопы^\
make trouble - причинять неприятности for somebody - кому-либо^\
make two bites of a cherry - прилагать излишние старания к очень легкому делу^\
make up a purse - собрать деньги (по подписке)^\
make up a quarrel - помириться, перестать враждовать^\
make up an inventory - произвести инвентаризацию^\
make up leeway - наверстать упущенное^\
make up one's mind - смириться something - чем-либо; решить, решиться^\
make up the fire - затопить печку^\
make use of - использовать, воспользоваться^\
make war - вести войну; вести войну on somebody - с кем-либо; воевать^\
make water - мочиться; дать течь (о корабле)^\
make way - дать дорогу, уступить место кому-либо, чему-либо^\
make whoopee - кутить^\
make your mind easy - успокойтесь^\
make yourself at home - будьте как дома^\
money makes money - деньги к деньгам^\
money makes the mare go - с деньгами многое можно сделать^\
nothing to make a song about - нечто,не заслуживающее внимания^\
one swallow does not make a summer - одна ласточка еще не делает весны^\
our own make - нашего производства^\
practice makes perfect - навык мастера ставит^\
promises are like piecrust,made to be broken - обещания для того и дают,чтобы их нарушать^\
promises made at large - неопределенные,неясные обещания^\
seek to make peace - пытаться помирить, попытаться помирить^\
she wouldn't make old bones - она не доживет до старости^\
the cheque was made opposite my name - чек был выписан на мое имя^\
the empty vessel makes the greatest sound - пустая бочка пуще гремит^\
the tailor makes the man - одежда красит человека; человека делает портной^\
two negatives make an affirmative - минус на минус дает плюс^\
two noes make a yes - два отрицания равны утверждению^\
we made an appointment for tomorrow - мы условились встретиться завтра^\
what makes him tick - чем он живет, что придает ему силы^\
you can't make an omelet without breaking eggs - лес рубят-щепки летят^\
Dictum sapienti sat est, verb. sap., verbum sap -для умного достачно^\
"+
/* http://study-english.info/everyday-idioms.php */
"\
after all - despite, nevertheless  - все-таки  - I knew it! After all, I was right!^\
all along - all the time  - все время, всегда  - I knew about his little secret all along.^\
all ears - eager to listen  - весь внимание  - I am all ears.^\
all of a sudden - suddenly  - неожиданно  - All of a sudden, he refused to pay.^\
all the same - no difference  - все равно, без разницы  - If it's all the same to you, let's start at two.^\
all thumbs - clumsy  - неуклюжий, неумелый  - He can't fix anything, he's all thumbs.^\
apple of discord - subject of envy or quarrel  - яблоко раздора  - This question is an apple of discord in our family.^\
as a rule - usually  - как правило  - As a rule, we offer a 5% discount.^\
as far as I am concerned - in my opinion  - что касается меня, по моему мнению  - As far as I am concerned, both the book and the movie are good.^\
as for me/as to me - in my opinion  - по моему мнению  - As for me, you can rely on his support.^\
as well - also, too  - тоже, также  - He knows math, and physics as well.^\
at all - (not) in the smallest degree  - совсем (не)  - He doesn't know French at all. I don’t like it at all.^\
at random - without order  - наугад, без плана  - He chose those places at random.^\
at this point - at this time  - на данном этапе  - At this point, we can't turn back.^\
be about to - ready (to do)  - готов сделать  - I was about to leave when you called.^\
be after someone - insist, press  - настаивать, чтобы сделал  - His mother is always after him to study.^\
be all in - be extremely tired  - очень устать  - I'm all in, I'd better go to bed now.^\
be back on one's feet - healthy again or better financially  - встать на ноги после трудного времени  - He's back on his feet after a long period of debt and unemployment.^\
beat around the bush - avoid giving a clear/definite answer  - ходить вокруг да около  - Stop beating around the bush! Get to the point!^\
be beside oneself - be very upset, nervous, worried, etc.  - быть вне себя от волнения, горя и др.  - She was beside herself with worry / with grief.^\
be better off - be in a better situation (financially)  - в лучшей ситуации (материально)  - He'll be better off with a new job.^\
be broke - have no money at all  - быть 'на мели' (без денег)  - I spent all my money, I'm broke.^\
be hard on something /someone - treat roughly  - не беречь что-то  - My son is hard on shoes, they don't last long with him. Life was pretty hard on Tom.^\
be high on one's list - be one of the most important things  - быть в начале списка нужных вещей  - A new car is high on my list of priorities. A new TV is not high on my list.^\
be in charge of - be responsible for  - быть ответственным за  - He is in charge of marketing.^\
be in the red - be in debt  - быть убыточным  - Our sales were in the red last year.^\
be into smth. - be interested in  - увлекаться чем-то  - He is into computers. She is into sports.^\
bend over backwards - try hard  - очень стараться  - I bent over backwards to help her.^\
be on one's way  - Я уже еду.  - I'm on my way.^\
be on the safe side - not to take any chances  - на всякий случай  - Take an extra key, just to be on the safe side.^\
be out of - be without  - нет в наличии  - We are out of bread, cheese, and sugar.^\
be out of shape - be physically unfit  - быть не в форме  - He needs to exercise, he is out of shape.^\
be out of sorts - in bad humor  - не в духе  - Leave him alone, he's out of sorts today^\
be pressed for time / money - be short of; not have enough  - не хватать времени или денег  - I'm pressed for time now. We are pressed for money at the moment.^\
beside the point - off the point  - не по существу, не относится к делу  - What I said to him privately is beside the point.^\
be to blame - be responsible for a mistake / something wrong  - винить за ошибку, неправильные действия  - Who is to blame for this awful mistake? Tom is to blame for this mix-up.^\
be touch and go - be uncertain of the result  - на грани; неясно, куда повернется  - He was very sick, and for some time it was touch and go, but he is better now.^\
be up against - be opposed by, have problems, be in danger  - иметь серьезные проблемы в чем-то, с чем-то  - Our company is up against serious attempts of hostile takeover.^\
be up and around/about - able to be out of bed after an illness  - встать на ноги, поправиться  - He was sick for a month, but now he is up and around.^\
be up to one's ears - very busy  - по уши  - I'm up to my ears in work.^\
be up to something - do mischief  - задумать, затеять  - I have to check what the kids are up to.^\
be up to someone - be one's own decision or responsibility  - на ваше усмотрение, под вашу ответственность  - It's up to you to decide. It's up to you to close the office every day at 8 o'clock.^\
be used to - be accustomed to  - быть привычным к  - I'm used to hard work. He's used to heat.^\
big shot - important person  - важная персона  - He is a big shot around here.^\
bite off more than one can chew - try to do more than one can  - переоценить свои силы  - I couldn't handle two jobs and family. I really bit off more than I could chew.^\
bite one's tongue - stop talking  - прикусить язык  - I almost told her, but bit my tongue.^\
bite the dust - die, be defeated  - умереть, падать ниц  - Many of them bit the dust in that war.^\
black sheep - a good-for-nothing member of the family  - паршивая овца  - Their second son is the black sheep of the family, he is good for nothing.^\
blind date - a meeting of a man and woman arranged by friends  - свидание вслепую  - She refuses to go on a blind date again because she had bad experience.^\
blow it - lose the chance  - потерять шанс  - He understood that he blew it.^\
blow over - pass, end  - стихнуть, пройти  - Wait here till his anger blows over.^\
bottom line - main result/factor  - итог, основной момент  - The bottom line is, I don't have enough money.^\
break into - enter by force  - ворваться (в дом) силой  - The police broke into the robber's house.^\
break one's heart - hurt deeply  - разбить сердце  - The news of her death broke his heart.^\
break the ice - overcome shyness in making the first step  - сломать неловкость при знакомстве  - The party was dull until someone broke the ice with a joke and we all laughed.^\
break the news - tell new facts  - сообщить важную новость  - CNN is breaking the news right now.^\
bring home the bacon - earn the living for the family  - обеспечить семью  - He works very hard at several places to bring home the bacon.^\
brush off - give no attention to  - отмахнуться от  - The boss brushed off my project again.^\
brush up on - review  - освежить в памяти  - You need to brush up on the tenses.^\
by all means -definitely, certainly  - обязательно, конечно  - Do you need my help? - By all means.^\
by heart - by memorizing  - наизусть  - Learn this poem by heart for tomorrow.^\
by hook or by crook - by any means possible  - любым путем, любым способом  - She will get what she wants by hook or by crook.^\
by the way - incidentally  - кстати  - By the way, Ann is coming back today.^\
call a spade a spade - use plain, direct words  - называть вещи своими именами  - He always tells the truth and calls a spade a spade.^\
call it a day - consider work finished for the day  - считать работу законченной  - We've been working for 10 straight hours. Let's call it a day.^\
call off - cancel  - отменить, отозвать  - The police called off the search.^\
carry out - fulfill  - доводить до конца  - She never carries out her plans.^\
carry weight - be important  - иметь вес  - His advice always carries weight here.^\
cast down - depressed, sad  - повергнуть в уныние  - He was cast down by the bad news.^\
castles in the air - daydreaming about success  - (строить) воздушные замки  - Instead of working hard, he spends time building castles in the air.^\
catch one's eye - attract attention  - привлечь внимание  - This picture caught my eye.^\
catch one's breath - stop and rest  - перевести дух  - I can't run, I need to catch my breath.^\
catch someone off guard - catch someone unprepared  - застать врасплох  - He caught me off guard with his question.^\
catch someone red-handed - find smb. in the act of doing wrong  - поймать за руку, когда делал плохое  - The manager caught the boy red-handed when he was stealing cigarettes.^\
catch up - become not behind  - догнать  - He needs to catch up with the others.^\
close call - a narrow escape, a bad thing that almost happened  - что-то плохое, что едва не случилось  - The speeding car almost hit the man. That was really a close call.^\
come across - meet by chance  - наткнуться на  - I came across that article yesterday.^\
come down with - become ill  - заболеть чем-то  - I'm coming down with a cold.^\
come to one's senses - start acting reasonably, intelligently  - взяться за ум, придти в себя  - He finally came to his senses, started to work hard, and passed his exams.^\
come true - become reality  - осуществиться  - My dream came true when I met Pat.^\
come up with - suggest  - предложить  - Mike came up with a brilliant idea.^\
count on - depend on  - рассчитывать на  - You can always count on me for help.^\
cut corners - to take a short-cut; to limit one's spending  - срезать углы; ограничить расходы  - He ran fast, cutting corners where he could. I have to cut corners this week.^\
cut down on - reduce  - сократить потребление  - You have to cut down on chocolate.^\
cut out to be /cut out for it - have the ability to do something  - быть созданным для какой-то работы  - She isn't cut out to be a surgeon. He's cut out to be a leader.^\
do one's best - try very hard  - сделать все, что смог  - I did my best to help him in his work.^\
do one's bit - do what's needed  - сделать положенное  - I'll do my bit, you can count on me.^\
do over - do again  - сделать заново  - This work is not good, do it over.^\
do someone good - be good for  - принести пользу  - Fresh air and exercise will do you good.^\
do something behind one's back - do (harmful) things secretively  - делать (вредные) дела за спиной  - I hate people who do things behind my back. He did it behind my back again.^\
do without - live without  - обходиться без  - I'll have to do without a car for a while.^\
down to earth - practical  - приземленный  - He's quiet, sensible and down to earth.^\
draw the line - fix a limit  - ограничить (предел)  - He drew the line for her at $100 a day.^\
dress up - put on the best clothes  - нарядиться  - What are you dressed up for?^\
drop off - deliver somewhere  - подвезти до, подбросить до  - Can you drop me off at the bank?^\
drop out - quit (school)  - быть отчисленным  - He dropped out of school last year.^\
duty calls - must fulfill obligations  - долг обязывает  - He said, \"Duty calls\" and left for work.^\
easier said than done  - легче сказать, чем сделать  - It's easier said than done, but I'll try to do it.^\
eat one's words - take back words  - брать назад слова  - He had to eat his words after her report.^\
even so - nevertheless, but  - тем не менее  - I work hard. Even so, I like my job.^\
every now and then -occasionally  - время от времени  - Every now and then I visit my old aunt.^\
every other - every second one  - через один  - She washes her hair every other day.^\
fall behind - lag behind  - отстать от  - The little boy fell behind the older boys.^\
fall in love - begin to love  - влюбиться  - Tom fell in love with Sue at first sight.^\
fall out of love - stop loving  - разлюбить  - They fell out of love and divorced soon.^\
false alarm - untrue rumor  - ложная тревога  - I heard he quit but it was a false alarm.^\
a far cry from something - very different, almost opposite (neg.)  - далеко не такой хороший, как  - His second book wasn't bad, but it was a far cry from his first book.^\
feel it in one's bones - expect something bad to happen  - чувствовать, что случится плохое  - Something bad is going to happen, I feel it in my bones.^\
feel like doing something - want to do, be inclined to do smth.  - быть склонным к занятию чем-то  - I feel like going for a walk. I don’t feel like working now, I’m tired.^\
feel up to - be able to do  - в состоянии сделать  - I don't feel up to cleaning the house.^\
few and far between - rare, scarce  - слишком редкие  - Her visits are few and far between.^\
find fault with - criticize  - критиковать  - He always finds faults with everybody.^\
find out - learn or discover  - узнать, обнаружить  - I found out that Maria left town.^\
firsthand - directly from the source  - из первых рук, достоверная информация  - You can trust it, it's firsthand information.^\
first things first - important things come before others  - сначала главное  - First things first: how much money do we have to pay right away?^\
fly off the handle - get angry  - разозлиться (вдруг)  - He flew off the handle and yelled at me.^\
follow in someone's footsteps - do the same thing  - идти по чьим-то следам, делать то же  - Igor followed in his father's footsteps, he became a doctor, too.^\
foot in the door - a special opportunity for a job  - получить шанс на работу  - Nina got a foot in the door because her friend works in that company.^\
foot the bill - pay the bill  - заплатить по счету  - Her father footed the bill for the party.^\
for good - forever  - навсегда  - After her death, he left town for good.^\
for the time being - at this time  - на данное время  - For the time being, this house is all right for us.^\
frame of mind - mental state  - умонастроение  - I can't do it in this frame of mind.^\
from A to Z - completely  - от начала до конца  - He knows this town from A to Z.^\
from now on - now and in the future  - впредь  - From now on, I forbid you to go there.^\
get a grip on oneself - take control of one's feelings  - контролировать свои чувства  - Stop crying! Get a grip on yourself!^\
get along with - have good relations  - быть в хороших отношениях, ладить  - Ann gets along with most coworkers, but doesn't get along with Laura.^\
get away with - not be caught after doing wrong  - уйти от наказания  - The police didn't find the thief. He got away with his crime.^\
get carried away - get too excited and enthusiastic about something  - слишком увлечься чем-то  - He got carried away with opening a store and lost most of his money.^\
get cold feet - be afraid to do  - побояться сделать  - I wanted to try it but got cold feet.^\
get even with - have one's revenge  - расквитаться с кем-то  - I'll get even with him for everything!^\
get in touch with - contact  - связаться с кем-то  - Get in touch with Mr. Smith for help.^\
get lost - lose one's way  - потерять дорогу  - She got lost in the old part of town.^\
Get lost! - Lay off!  - Исчезни!  - I don't want to see you again. Get lost!^\
get mixed up - get confused  - перепутать  - I got mixed up, went the wrong way and got lost.^\
get off one's back - leave alone  - отстать от кого-то  - Stop bothering me! Get off my back!^\
get on one's high horse - behave haughtily towards someone  - вести себя высокомерно  - Every time I ask her to help me with typing, she gets on her high horse.^\
get on (the bus, train, plane)  - сесть на (транспорт)  - I got on the bus on Oak Street.^\
get off (the bus, train, plane)  - сойти с (транспорта)  - I got off the bus at the bank.^\
get out of hand - get out of control  - выйти из-под контроля  - If he gets out of hand again, call me right away.^\
get over - recover after an illness or bad experience  - поправиться, преодолеть что-то  - I can't get over how rude he was to me. She got over her illness quite quickly.^\
get rid of - dispose of, discard  - избавиться  - He got rid of his old useless car.^\
get together - meet with  - собираться вместе  - My friends and I get together often.^\
get to the bottom - know deeply  - добраться до сути  - He usually gets to the bottom of things.^\
get to the point - get to the matter  - дойти до сути дела  - Get to the point!^\
Give me a break! - spare me  - с меня хватит  - Come on, stop it! Give me a break!^\
give someone a hand - help  - помочь кому-то  - Can you give me a hand with cooking?^\
give someone a lift /a ride - take to some place by car  - подвезти кого-то  - Can you give me a lift to the bank? He gave her a ride in his new Porsche.^\
give someone a piece of one's mind - criticize frankly  - высказать, что на уме, критиковать  - She lost my umbrella again, so I gave her a piece of my mind about her carelessness.^\
give up - stop doing something, stop trying to do something  - отказаться от чего-то, прекратить попытки  - I gave up smoking. I gave up trying to fix my old car.^\
go back on one’s word - break a promise  - нарушить свое слово, обещание  - First he said he would help me, but then he went back on his word.^\
go for it - try to do a new thing  - пробовать новое дело  - If I were you, I would go for it.^\
go from bad to worse - be worse  - становиться все хуже  - His business went from bad to worse.^\
go out - go to parties, movies  - пойти развлекаться  - Do he and his wife go out often?^\
go out of one's way -try very hard  - очень стараться  - He goes out of his way to please her.^\
go to one's head - make too proud  - успех вскружил голову  - His acting success went to his head.^\
go to pieces - get very upset, fall apart  - сильно расстроиться  - She went to pieces when she heard it.^\
go with the flow - lead quiet life  - плыть по течению  - She always goes with the flow.^\
grow on someone - become liked  - постепенно понравиться  - When she knew him more, he grew on her.^\
had better - should  - лучше бы, а то…  - You look ill, you'd better see a doctor.^\
have a ball - have a good time  - отлично провести время  - Yesterday we had a ball at the party.^\
have a bone to pick - complain or discuss something unpleasant  - иметь счеты с кем-то, претензии к кому-то  - Mr. Brown, I have a bone to pick with you. My mail was lost because of you.^\
have a word with someone - talk to  - поговорить о чем-то  - Can I have a word with you?^\
have words with someone - argue with someone about something  - крупно поговорить  - I had words with my coworker today because he used my computer again.^\
have it in him - have the ability  - иметь нужные качества  - Laura has it in her to be a good doctor.^\
have no business doing something - have no right to do  - нечего вам здесь делать, быть и др.  - You have no business staying here without my permission.^\
have one's back to the wall - be hard-pressed, on the defensive  - быть прижатым к стене  - I had no choice, I had my back to the wall.^\
have one's hands full - very busy  - быть очень занятым  - He has his hands full with hard work.^\
have one's heart set on something - want something very much  - очень хотеть получить что-то, кого-то  - She has her heart set on going to New York. He has his heart set on Betty.^\
have pull - have influence on  - иметь влияние на  - Does he have pull with the director?^\
(not) have the heart - (not) have the courage to do smth. unpleasant  - (не) хватает духа сделать неприятное  - I don't have the heart to tell him that he wasn't accepted, he'll be so unhappy.^\
high and low - everywhere  - везде (искать и т.д.)  - I searched high and low for my lost cat.^\
hit the nail on the head - say exactly the right thing  - попасть в точку  - You hit the nail on the head when you said our company needs a new director.^\
hit upon something - to discover  - обнаружить ценное  - They hit upon gold. I hit upon a plan.^\
hold it against someone - blame somebody for doing something  - (не) держать зла на кого-то  - I lost his book, but he doesn't hold it against me.^\
Hold it! - Stop! Wait!  - Остановитесь/Стойте!  - Hold it! I forgot my key.^\
Hold on! - Wait!  - Подождите!  - Hold on! I'll be back in a minute.^\
hold one's own - maintain oneself in a situation, behave as needed  - постоять за себя, утвердиться в чем-то  - He can hold his own in any situation. We need men who can hold their own.^\
hold up - rob using a weapon  - грабить с применением оружия  - This bank was held up twice last year.^\
ill at ease - uncomfortable  - не по себе  - She felt ill at ease because of her cheap dress.^\
in advance - well before  - заранее  - He told her about his plan in advance.^\
in a nutshell - in a few words  - кратко, вкратце  - In a nutshell, my plan is to buy land.^\
in care of someone - write to one person at the address of another  - адресату по адресу другого человека (у кого остановился)  - I'm staying at Tom's house. Write to me in care of Tom Gray, Chicago, Illinois.^\
in cold blood - mercilessly  - хладнокровно  - He killed her in cold blood.^\
in fact - actually, in reality  - фактически  - In fact, he works as a manager here.^\
in general - generally, generally speaking  - в общем, вообще  - In general, he likes to be alone. He described the place only in general.^\
in one's element - what one likes  - в своей стихии  - He's in his element when he's arguing.^\
in other words - using other words  - другими словами  - In other words, you refused to do it for her.^\
in plain English - in simple, frank terms  - проще говоря  - I didn't really like the concert. In plain English, the concert was terrible.^\
the ins and outs - all info about  - входы и выходы  - He knows the ins and outs of this business.^\
in someone's shoes - in another person's position  - на месте другого, в положении другого  - I'd hate to be in his shoes now. He lost his job, and his wife is in the hospital.^\
in the long run - in the end  - в конечном счете  - In the long run, it'll be better to buy it.^\
in the same boat - in the same situation  - в таком же положении  - Stop arguing with me, we're in the same boat and should help each other.^\
in the clear - free from blame  - вне претензий  - Pay the bill and you'll be in the clear.^\
in time (to do something) - before something begins  - придти вовремя, чтобы успеть что-то сделать (до начала чего-то)  - I came in time to have a cup of coffee before class.^\
it goes without saying - should be clear without words  - не стоит и говорить, само собой  - It goes without saying that he must pay what he owes right away.^\
It's on the tip of my tongue.  - вертится на языке  - His name is on the tip of my tongue.^\
it's time - should do it right away  - пора  - Hurry up, it's time to go.^\
It's worth it. / It's not worth it. It’s (not) worth buying, visiting, watching, etc.  - оно того стоит /оно того не стоит; (не) стоит покупать, посетить, смотреть и т.д.  - Watch this film, it's worth it. Don't buy this coat, it is not worth it. This museum is worth visiting. This film is not worth watching.^\
it will do - it's enough  - достаточно  - Stop reading, it will do for now.^\
jump at the opportunity/chance - accept the opportunity eagerly  - ухватиться за возможность  - His boss mentioned a job in Europe, and Peter jumped at the opportunity.^\
just as soon - prefer this one  - предпочел бы (это)  - I'd just as soon stay home, I'm tired.^\
just in case - to be on the safe side  - на всякий случай  - Take an extra shirt, just in case.^\
Just my luck! - Bad / Hard luck!  - Мне всегда не везет!  - They lost my job application. Just my luck!^\
keep an eye on - take care of, watch, look after  - последить за, присмотреть за  - Betty keeps an eye on my sons for me. I’ll keep an eye on you!^\
keep a straight face - not to laugh  - стараться не смеяться  - I tried to keep a straight face, but failed.^\
keep company - accompany  - составить компанию  - She keeps me company quite often.^\
keep one's word - fulfill a promise  - держать слово  - You promised, now keep your word.^\
keep someone posted - inform  - держать в курсе событий  - Keep me posted about your plans.^\
keep your fingers crossed - hope that nothing will go wrong  - надеяться, что все пройдет гладко  - I have a job interview today. Keep your fingers crossed for me, will you?^\
kill time - fill/spend empty time  - убить время  - I went to the show to kill time.^\
(not) know the first thing about - not to have any knowledge about  - ничего не знать по какой-то теме  - I don't know the first thing about nuclear physics.^\
know the ropes - be very familiar with some business  - знать все ходы и выходы  - He knows all the ropes in this company.^\
last-minute notice - little or no time to prepare for something  - сообщение в последний момент  - His arrival was a last-minute notice, we didn't have time to prepare for it.^\
lay one's cards on the table - be frank and open  - сказать честно, открыть карты  - Finally, we asked him to lay his cards on the table and tell us about his plans.^\
lay one's life on the line - put oneself in a dangerous situation  - ставить жизнь на карту  - He laid his life on the line to fulfill this task, but nobody appreciated his efforts.^\
lead a dog's life - live in misery  - вести собачью жизнь  - He leads a dog's life.^\
lead someone on - make someone believe something that isn't true  - заставить кого-то поверить неправде  - They suspect that you are leading them on. You led me on!^\
leave it at that - accept reluctantly  - оставить как есть  - Leave it at that, what else can you do?^\
leave word - leave a message  - оставить сообщение  - He left word for you to meet him at the airport at 6.^\
let bygones be bygones - forget and forgive bad things in the past  - не ворошить прошлое  - Why don't you let bygones be bygones and forget about what he said?^\
let go of - release the hold  - отпустить, не держать  - Let go of my hand or I'll call the guard.^\
let (it) go - forget bad experience, return to normal life  - освободиться от тяжелого переживания  - He's still in despair and can't let (it) go. You can’t change anything, so let it go.^\
let one's hair down - be relaxed and informal with other people  - держаться неофициально  - She is always so formal. She never lets her hair down.^\
let someone down - disappoint, fail someone  - подвести кого-то  - Don't let me down this time!^\
let someone know - inform  - известить  - Let me know when you find a job.^\
like father, like son - be like one's parent in something  - какой отец, такой и сын  - Paul won a prize in a chess tournament. Great! Like father, like son!^\
little by little - step by step  - понемногу  - Little by little, he got used to Tokyo.^\
look for - search for  - искать  - What are you looking for?^\
look forward to - expect with pleasure  - ожидать с нетерпением  - I'm looking forward to your letter. Mary is looking forward to the party.^\
look out - be careful, watch out  - остерегаться  - Look out! The bus is coming!^\
look up - check with /in a dictionary or a reference book  - посмотреть в словаре или справочнике  - If you don’t know this word, look it up in the dictionary.^\
lose one's temper - become angry  - разозлиться  - He loses his temper very often.^\
lose one's way - get lost  - потерять дорогу  - I lost my way. Can you help me?^\
lose track of - not to know where someone or something is  - потерять из виду  - I lost track of him years ago.^\
lucky break - a lucky chance  - счастливый случай  - He got his lucky break when he got this job.^\
make a living - earn money to provide for life  - зарабатывать на жизнь  - He works hard. His family is big, and he has to make a living somehow.^\
make allowance for - take into consideration when judging  - учитывать, делать скидку на  - Don't criticize him so hard, make (an) allowance for his inexperience.^\
make a point of - be sure to do something intentionally  - считать обязательным для себя сделать что-то  - Make a point of asking about his wife. Make it a point to be here by 10.^\
make ends meet - to have and spend only what one earns  - сводить концы с концами  - His doesn’t get much money. I wonder how he manages to make ends meet.^\
make friends - become friends  - подружиться  - Anton makes new friends easily.^\
make fun of - laugh at, joke about  - высмеивать  - He made fun of her German accent.^\
make no bones about it - say/do openly, without hesitation  - сказать прямо, не скрывая отношения  - I'll make no bones about it: I don't like your attitude to work.^\
make room for - allow space for  - освободить место для  - We can make room for one more dog.^\
make sense - be logical  - имеет смысл  - What you say makes sense.^\
make the most of smth - do the best in the given situation  - извлечь лучшее из  - Let's make the most of our vacation.^\
make up - become friends again  - помириться  - I'm tired of fighting. Let's make up.^\
make up for smth - compensate  - компенсировать  - I'll make up for the time you spent on it.^\
make up one's mind - decide  - принять решение  - When will you go? Make up your mind.^\
make yourself at home - be comfortable, feel at home  - будьте как дома  - Come in please. Make yourself at home.^\
man of his word - one who keeps promises, is dependable  - хозяин своего слова, держит слово  - You can depend on his promise to help. He's a man of his word.^\
mean well - have good intentions  - хотеть сделать, как лучше  - He meant well, but it turned out that he spoiled a couple of things for me.^\
might as well - a good idea  - может быть неплохо  - I might as well telephone him now.^\
missing person - someone who is lost and can't be located  - пропавший человек (в розыске)  - The little boy disappeared. The police registered him as a missing person.^\
meet someone halfway - compromise with others  - идти на компромисс с кем-то  - He's reasonable and tries to meet his coworkers halfway, when possible.^\
never mind - it doesn't matter  - неважно, ничего  - Thank you. - Never mind.^\
not to mention - in addition to  - не говоря уж  - We have three dogs, not to mention two cats.^\
no wonder - not surprising  - неудивительно, что  - He ate three big fish. No wonder he's sick.^\
now and again - occasionally  - время от времени  - I meet them now and again at the bank.^\
odds and ends - a variety of small unimportant things or leftovers  - мелочи, остатки, обрезки  - I needed to buy some odds and ends for the kitchen.^\
off the cuff - without preparation  - без подготовки  - Off the cuff, I can give you only a rough estimate.^\
off the point - beside the point  - не относится к делу  - What I think about him is off the point.^\
off the record - not for the public, unofficially  - не для публики, неофициально  - Strictly off the record, I think the director is going to get married soon.^\
once and for all - decidedly  - однажды и навсегда  - You must quit smoking once and for all.^\
on credit - not pay cash right away  - в кредит  - He bought a car on credit.^\
on edge - nervous, irritable  - нервный, раздраженный  - He's been on edge ever since she left.^\
on guard - on the alert  - настороже, бдительный  - He's cautious and always on guard.^\
on hand - available  - под рукой  - Do you have a calculator on hand?^\
on one's own - alone, by oneself  - самостоятельно, один, сам по себе  - She likes to live and work on her own.^\
on one's toes - alert, attentive, prepared for difficulties  - бдительный, собранный  - He was on his toes and produced a very good impression on them.^\
on purpose - intentionally  - нарочно, с целью  - I didn't do it on purpose, it just happened so.^\
on second thought - after thinking again  - по зрелом размышлении  - I'd like to sit on the aisle. On second thought, I'd like a window seat.^\
on the alert - on guard  - начеку, настороже  - He's cautious and always on the alert.^\
on the carpet - called in by the boss for criticism  - вызвать на ковер  - Yesterday the boss called her on the carpet for being rude to the coworkers.^\
on the go - busy, on the move  - в движении, на ходу  - He is always on the go.^\
on the off chance - unlikely to happen, but still  - маловероятно, но на всякий случай  - On the off chance that you don't find him at work, here's his home address.^\
on the other hand - considering the other side of the question  - с другой стороны  - I'd like to have a dog. On the other hand, my wife likes cats better.^\
on the spot - right there  - на месте, сразу  - I decided to do it on the spot.^\
on the spur of the moment - without previous thought / plan  - под влиянием момента  - He bought this car on the spur of the moment, now he regrets it.^\
on time - punctual  - в назначенное время  - Jim is always on time.^\
out of one's mind - crazy  - сумасшедший  - If you think so, you're out of your mind.^\
out of one's way - away from someone's usual route  - не по пути  - I can't give you a lift to the bank, it's out of my way today.^\
out of the question - impossible  - не может быть и речи  - Paying him is out of the question!^\
pack rat - a person who saves lots of unnecessary things  - тот, кто не выбрасывает старые ненужные вещи  - Why does she keep all those things she never uses? - She is a pack rat.^\
pay attention - be attentive  - обратить внимание  - Pay attention to his words.^\
pick a fight - start a quarrel  - начать ссору  - He often tries to pick a fight with me.^\
pick up - take, get  - подобрать, взять  - I'll pick you up at 7.^\
play one's cards right - choose the right steps in doing something  - сыграть правильно  - If you play your cards right, he'll agree to your plan.^\
potluck supper - a surprise meal, where nobody knows what dishes other guests will bring  - ужин вскладчину, никто не знает, что принесут другие  - You know what happened at our last potluck supper? Everybody brought macaroni and cheese, apples, and beer!^\
pull oneself together - brace oneself, summon your strength  - cобраться с силами  - Stop crying and complaining! You have to pull yourself together now.^\
pull the wool over someone's eyes - deceive, mislead someone  - обмануть, ввести в заблуждение  - Are you trying to pull the wool over my eyes? It won't do you any good.^\
put a damper on - discourage  - охладить пыл  - She always puts a damper on my plans.^\
put in a word for someone - say positive things about someone  - замолвить словечко  - I'd be very grateful if you could put in a word for me when you speak to him.^\
put off - postpone  - откладывать  - Don't put it off till tomorrow.^\
put one's foot down - object strongly  - решительно воспротивиться  - Her father put his foot down when she said she wanted to marry Alan.^\
put one's foot in it - do the wrong thing, make a fool of oneself  - сделать/сказать глупость  - He put his foot in it when he told the boss his daughter wasn't pretty.^\
put up with - accept, tolerate  - мириться с, терпеть  - I can't put up with your bad work!^\
quite a bit of - much, a lot of  - много  - I had quite a bit of trouble with that car.^\
quite a few - many, a lot of  - много  - He wrote quite a few good stories.^\
rack one's brain - try hard to think  - напрячь мозги  - He racked his brain to solve the puzzle.^\
read between the lines - find or understand the implied meaning  - читать между строк  - His books are not easy to understand; you have to read between the lines.^\
remember me to - say hello to  - передать привет от  - Please remember me to your family.^\
right away - immediately  - сразу же, немедленно  - It' very important to do it right away.^\
ring a bell - remind someone of something familiar /half-forgotten  - напоминает что-то знакомое  - Annabel Lee? Yeah, it rings a bell, but I can't place it right now.^\
rock the boat - make the situation unstable  - раскачивать лодку, вести к нестабильности  - Peter always rocks the boat when we discuss company's spending policy.^\
rub shoulders with - meet with  - близко общаться с  - He doesn't rub shoulders with the rich.^\
rub someone the wrong way - irritate, annoy, make angry  - раздражать, злить кого-то  - His remarks rub many coworkers the wrong way.^\
run into - meet by chance  - случайно встретить  - I ran into an old friend yesterday.^\
save face - try to change the negative impression produced  - спасать репутацию  - He said a stupid thing and tried to save face by saying he misunderstood me.^\
save one's breath - stop useless talk  - не трать слова попусту  - There's no use talking to him about his spending habits, so save your breath.^\
scratch the surface - study something superficially  - изучать поверхностно  - He examines all the facts closely, he doesn't just scratch the surface.^\
see about - make arrangements for  - позаботиться о чем-то  - I have to see about our plane tickets.^\
see eye to eye - agree  - сходиться в мнении  - We don't see eye to eye any longer.^\
serve someone right - get what someone deserves  - поделом  - It serves him right that he didn't get this job, he despised all other candidates.^\
serve one's purpose - be useful to someone for his purpose  - отвечать цели  - I doubt that hiring this man will serve your purpose.^\
show promise - be promising  - подавать надежды  - This young actor shows promise.^\
show up - appear  - появиться  - I waited for hours but he didn't show up.^\
size up - evaluate someone  - оценить, составить мнение  - It took me 5 minutes to size up that man.^\
sleep on it - postpone a decision till next morning  - отложить решение до следующего утра  - Don't decide now, sleep on it.^\
a slip of the tongue - a mistake  - обмолвка (ошибка)  - It was just a slip of the tongue!^\
slip (from) one's mind - forget  - забыть  - It slipped my mind what she asked me.^\
smell a rat - suspect something  - подозревать недоброе  - I'm not sure what it is, but I smell a rat.^\
so far - up to now  - до сих пор, пока  - So far, I have read 3 books by King.^\
so much the better - it's even better  - еще лучше  - If he can pay cash, so much the better.^\
spill the beans - tell a secret  - проболтаться  - Who spilled the beans about our plan?^\
stand a chance - have a chance  - нет шансов  - He doesn't stand a chance of getting it.^\
stand out - be noticeable  - выделяться  - He stands out in any group of people.^\
stand to reason - be logical  - логично, что  - It stands to reason that he apologized.^\
straight from the shoulder - speak frankly  - честно, откровенно  - Don't try to spare my feelings, give it to me straight from the shoulder.^\
take a dim view of something - disapprove of something  - не одобрять  - My sister takes a dim view of the way I raise my children.^\
take a break - stop for rest  - сделать перерыв  - Let’s take a break, I’m tired.^\
take advantage of - use for one's own benefit, to profit from  - воспользоваться возможностью  - We took advantage of the low prices and bought a computer and a monitor.^\
take after - be like one of the parents  - быть похожим на родителей (родителя)  - Tom takes after his father in character, and after his mother in appearance.^\
take a stand on something - make a firm opinion/decision on smth.  - занять четкую позицию, мнение  - People need to take a stand on the issue of nuclear weapons.^\
take care of - look after, protect, see that smth. is done properly  - позаботиться о ком-то, чем-то, присмотреть за  - Can you take care of my dog while I’m away? Tom takes good care of his car.^\
take hold of something - take, hold  - взять, держать  - Take hold of this rope and pull.^\
take into account - consider smth.  - принять во внимание  - You must take into account her old age.^\
take it easy - relax, be calm  - не волнуйся  - Take it easy, everything will be OK.^\
take (it) for granted - accept as given  - принимать как должное  - Mother's love is always taken for granted by children.^\
take one's breath away  - захватить дух  - That great view took my breath away.^\
take one's time - do slowly  - делать не торопясь  - Don't hurry. Take your time.^\
take one’s word for it - believe  - поверить на слово  - Take my word for it, he won’t go there.^\
take pains - try hard to do it well  - прилагать усилия  - He took pains to make his report perfect.^\
take part in smth. - participate in  - принять участие  - Mary is going to take part in the show.^\
take place - happen  - иметь место, случиться  - The accident took place on Oak Street.^\
take someone's mind off things - distract from fixed ideas/thoughts  - отвлечь от навязчивых мыслей  - Go to a concert or a movie to take your mind off things.^\
take steps - take action /measures  - принимать меры  - We need to take steps against it.^\
take the words right out of one's mouth - say the same before somebody else says it  - сказать то же самое чуть раньше, чем другой говорящий  - I was about to say the same! You took the words right out of my mouth.^\
take time - take a long time  - занять много времени  - It takes time to get used to a new place.^\
take time off - be absent from work  - взять отгул  - He took time off to attend the wedding.^\
take turns - alternate doing something one after another  - делать по очереди, меняться местами  - We went to Minsk by car. We didn't get tired because we took turns driving^\
talk back - answer rudely  - дерзить  - Don't talk back to the teacher!^\
talk it over - discuss  - обсудить с кем-то  - I'll talk it over with my family.^\
tell apart - see the difference  - различить, отличить от  - Can you tell the twins apart?^\
That's just the point. - That's it.  - В этом-то и дело.  - That's just the point! I hate this job!^\
the writing on the wall - a sign of future events (usually, trouble)  - предзнаменование (обычно, беды)  - The plane crashed. Tim said he saw the writing on the wall about this flight.^\
not think much of - think low  - невысокого мнения  - I don't think much of her cooking.^\
think over - consider carefully  - обдумать  - Think over your answer. Think it over carefully.^\
till one is blue in the face - try hard  - стараться до посинения  - I repeated it till I was blue in the face!^\
to make a long story short - in short  - короче говоря  - To make a long story short, we won.^\
to say the least - to make the minimum comment about smth.  - самое малое, что можно сказать  - The film was boring and long, to say the least.^\
try on - put on new clothes to test them for size or look  - примерить одежду (перед покупкой)  - Try on this leather coat, it's very good. She tried it on, but it didn’t fit her at all.^\
try one's hand at something - try  - попробовать себя в  - I want to try my hand at painting.^\
turn on / off - switch on / off  - включить/выключить  - Turn on the radio. Turn off the water.^\
turn out to be - result/end this way  - оказаться  - He turned out to be a very good actor.^\
turn over a new leaf - make a fresh start in life, work, etc.  - начать (жизнь, новое дело) заново  - He promises to turn over a new leaf and quit alcohol for good.^\
turn the tide - reverse the course of events  - повернуть вспять ход событий  - The new evidence turned the tide, and the defendant was acquitted of charges.^\
twist one's arm - make to agree  - выкручивать руки  - They twisted his arm to sell the house.^\
under the weather - feel ill  - нездоровится  - I'm a little under the weather today.^\
up-and-coming - showing promise of future success  - многообещающий, подающий надежды  - He is an up-and-coming young lawyer who might help you with your case.^\
up in arms - hostile to, in strong protest against something  - протестовать против, сопротивляться  - The employees are up in arms about the new retirement rules.^\
up in the air - undecided  - еще не определено  - My vacation plans are still up in the air.^\
(not) up to par - equal in standard  - (не) в норме  - His behavior isn't up to par.^\
used to - did often in the past, but not now  - в прошлом делал, сейчас нет  - I used to play the piano when I was in school (but I don't play it now).^\
walk on air - be very happy  - летать от счастья  - He got the job and is walking on air now.^\
waste one's breath - speak uselessly, to no purpose  - не трать усилия зря  - Don't waste your breath trying to make him do it, he won't change his mind.^\
watch one's step - be careful  - быть осмотрительным  - Watch your step!^\
watch out - look out, be careful  - остерегаться  - Watch out for that car! Watch out!^\
wet blanket - a kill-joy, who spoils everybody's fun  - тот, кто портит всем удовольствие  - Remember what a wet blanket he was last time? Please don't invite him again.^\
What's the matter? - What is it?  - В чем дело?  - What's the matter? What happened?^\
which way the wind blows - what the real situation is  - какова реальная ситуация  - He knows which way the wind blows and always acts accordingly.^\
white lie - unimportant lie  - невинная ложь  - A white lie is told to spare your feelings.^\
word for word - in the same words  - дословно, дословный  - Tell me word for word what he said.^\
would rather - prefer  - предпочитать  - I'd rather stay at home today.^\
"+
/* http://engmaster.ru/idiom */
"\
A little bit - немного, чуточку - I only had a little bit to eat this morning and now I feel awfully hungry.^\
A little frog in a big pond - незначительный человек в большой группе - Rick is aware of the fact that he is but a little frog in a big pond in this huge company.^\
A piece of cake - что-то лёгкое, простоё; проще пареной репы; щелкать как орешки. - Solving math problems is a piece of cake for him.^\
Abandon oneself to - поддаться ( чувствам,разочарованию) - He abandoned himself to despair.^\
Abide by (something) - придерживаться правил - If you want to be a member of this society, you are to abide by its rules.^\
Able to breathe easily again - вздохнуть свободно - When Hillary paid her bank loan, she was able to breathe easily again.^\
Able to do (something) blindfolded - делать что-то вслепую, делать что-то легко и быстро - Jim has always been a skilled worker; he does his job blindfolded.^\
Able to take a joke - уметь посмеяться над собой - Not everybody is able to take a joke; I, for example, can’t stand when people make fun of me.^\
About time - пора бы - I am very annoyed with you; it’s about time you minded your own business.^\
About to (do something) - собираться делать что-то - We were about to leave the house when it started to rain.^\
Above and beyond - больше, чем требуется; больше, чем нужно - I appreciate your kindness; you did above and beyond to help me.^\
Above reproach - безупречный (ая, ое), вне критики - Bill is a well-mannered young man; his behavior is above reproach^\
Above suspicion - вне подозрения - Henry acted as if he were above suspicion, but I am sure he is guilty.^\
Absent-minded - рассеянный - I don’t think much of Jack; he is so absent-minded.^\
According to Hoyle - согласно правилам, делать что-либо строго по правилам - According to Hoyle, the in-patients are not allowed to leave the hospital grounds.^\
Acid look - кислое выражение лица - What the matter with you? You have such an acid look.^\
Acid test - серьёзное испытание, пробный камень - The money problem was an acid test in their relationships.^\
Acquire a taste for (something) - приобрести вкус к чему-либо - Having visited an art gallery, he acquired a taste for modern art.^\
Across the board - равный для всех и для всего - The owner of the house increased the rent across the board, and all the tenants had to pay 50 dollars more.^\
Act high and mighty - вести себя высокомерно и властно - Stella acted high and mighty that’s why no one liked her.^\
Act of God - стихийное бедствие - Despite all Acts of God, we continue to destroy our planet.^\
Act one's age - вести себя по взрослому - My niece is in her early thirties, but she prefers not to act her age.^\
Act up - вести себя плохо - The students often act up during the breaks.^\
Act up - вести себя вызывающе - Don't act up, it's not your habit!^\
Adam's ale - вода^\
Adam's apple - кадык - Adam's apple moves up and down when one speaks.^\
Add fuel to the fire - подлить масла в огонь - I wanted to calm him down, but my words only added fuel to the fire.^\
Add insult to injury - наносить новые оскорбления - I felt pretty bad because my car had broken down, and instead of feeling sorry for me my father added insult to injury.^\
Add up - подсчитывать, складывать, находить сумму - In vain George was trying to add up the figures, but they just wouldn’t add up.^\
Adulterate milk - разбавленное, фальсыфицированное молоко - I never buy milk at the market, it can be adulterated.^\
Afraid of one's own shadow - бояться собственной тени - Don’t be a coward; it’s silly of you to be afraid of your own shadow.^\
After all - 1.в конце концов, после всего 2.в конечном счёте - Mother doesn’t need to help Phil get dressed. After all, he is a big boy.^\
Against one's will - против чьей-то воли - I don’t want you to do it against your will.^\
Against the clock - торопиться что-либо сделать пока не поздно - They worked against the clock to complete the job.^\
Agree to differ - остаться при своём мнении - Let's agree to differ^\
Ahead of one's time - опередивший своё время, свою эпоху (во взглядах, поступках и т.д.) - Newton’s ideas in physics were very much ahead of his time.^\
Ahead of the game - делать больше, чем необходимо - The company secretary did more work that day to be ahead of the game the next day.^\
Ahead of time - раньше времени, раньше срока - I asked the permission of my boss to leave work ahead of time^\
Air (something) out - проветривать что-либо - I’d like to put the rugs outside to air them out.^\
Air one's grievances - жаловаться прилюдно - During the war their houses were destroyed so they couldn’t but air their grievances to the journalists.^\
Air one`s dirty laundry/linen in public - выносить сор из избы, перемывать грязное бельё при всех - It pleased Greg immensely to air other people’s dirty laundry in public.^\
Alas! - К сожалению - Alas, my friend, the boast is poor...^\
Alive and well/kicking - быть живым и здоровым - At the age of 95 my Uncle Tobias is still alive and kicking.^\
All aboard! - посадка окончена^\
All alone - самостоятельно, в полном одиночестве - He made this project all alone^\
All along - всё время - Jeremy has known about my problems all along.^\
All around - кругом, везде - I looked all around but I still can't find my keys^\
All at once - внезапно, без предупреждения - внезапно, без предупреждения^\
All ears - быть готовым выслушать кого-либо - If you want me to hear you out, I am all ears.^\
All for (someone or something) - быть целиком за - I was all for going on a picnic, the day being so sunny.^\
All in - уставший - After this work I am all in^\
All in a day's work - часть того, что нужно делать; что-то ожидаемое - It was all in a day's work when the police arrested the criminal.^\
All in all - суммарно, в целом - There were twelve people all in all at the parents’ meeting that day.^\
All in one piece - целым и невредимым - As we packed all the breakable things carefully, we hoped that they would arrive all in one piece.^\
All night long - всю ночь напролёт - I couldn’t sleep well because people were shouting outside my window all night long.^\
All of a sudden - внезапно, вдруг - We were watching television when all of a sudden the electricity went off.^\
All over - всё, конец - It is all over with him^\
All right - нормально - \"How's your chemistry class?\" \"It's all right, I guess, but it's not the best class I've ever had.\"^\
All set - всё готово (можно начинать) - It was all set and we decided to start on our journey.^\
All sweetness and light - казаться хорошим, невинным - Outwardly Celia is all sweetness and light, but I know she is not that good.^\
All talk (and no action) - одни разговоры, а дела нет - I wouldn’t rely on Paul; he is all talk and no action.^\
All the rage - последний писк (о моде) - I strongly advise you to buy these jeans; they are all the rage of the season.^\
All thumbs - неловкий, неуклюжий (все пальцы на руке – большие) - Little Sam broke a cup and his Mom said he was all thumbs.^\
All to the good - всё к лучшему - “It is all to the good that you walked out on your boy friend”, my mother said.^\
All told - всё вместе, всё включительно - All told, there are six rooms in the house including the kitchen.^\
All-out-effort - большое, значительное усилие - Lionel made an all-out-effort to remain calm.^\
Also ran - неудачник - I always knew that you are an also ran.^\
Amenities of home life - радости семейной жизни - Bill was happily married and enjoyed amenities of home life^\
Ammunition leg - протез - He was injured at the war and had to wear an ammunition leg^\
Amount to (something) - быть успешным - I am afraid you will never amount to anything if you don’t work hard.^\
Amount to the same thing - быть одинаковым, иметь тот же эффект - You can either take a taxi or go by bus; it will amount to the same thing.^\
An apple-pie order - полный порядок - Helen's room was always in an apple-pie order^\
An arm and a leg - огромная сумма денег - Their new house will cost them an arm and a leg.^\
An oddball - чудак, своеобразно мыслящий человек - Adam Smith is an oddball, and very often he doesn’t act like other people.^\
Anchor one's hope (in,on) - возлагать надежды на - She anchored her hopes on her only son.^\
Anguish of body and mind - физические и душевные страдания - Communication with them gave her real anguish of body and mind^\
Answer to (someone) - отвечать перед кем-либо, объяснять свои действия - Bill lived on his own; he had no family and consequently no one to answer to.^\
Any number of (someone or something) - достаточное количество - You always have any number of missing classes and excuses^\
Apparent to the naked eye - видимый невооруженным глазом - The bruises on her face were apparent to the naked eye^\
Appeal to reason - аппелировать к здравому уму - The President appealed to reason but all in vain^\
Appear out of nowhere - внезапно появиться, появиться ниоткуда - A big lorry appeared out of nowhere and splashed mud all over me.^\
Apple of (one`s) eye - любимчик (зеница ока) - Her little son is the apple of her eye.^\
Argue for the sake of arguing/argument - спорить ради спора - William likes to argue for the sake of arguing.^\
Arm in arm - под руку (идти под руку) - Amiss and Cora were walking arm in arm in the park.^\
Armed and dangerous - вооружен и опасен - The criminal was suspected of being armed and dangerous.^\
Armed to the teeth - вооружен до зубов - The police stopped a car. The man in the car was armed to the teeth.^\
Around the clock - 24 часа, сутки - Most of the supermarkets in big American cities work around the clock.^\
Arrive on the scene - прибыть на место происшествия - Tim dialed 911 and the police arrived on the scene almost at once.^\
Artificial respiration - искуственное дыхание - The boy was seriously injured and badly needed artificial respiration.^\
As a (general) rule - обычно - He can be found in his office as a general rule.^\
As a duck takes to water - естественно - She took to singing just as a duck takes to water^\
As a last resort - последняя мера, последнее средство (когда всё остальное испробовано) - As a last resort John decided to take a loan from the bank.^\
As a matter of fact - на самом деле - As a matter of fact, John came into the room while you were talking about him.^\
As a token (of something) - в знак благодарности - Here, take this $100 as a token of my appreciation.^\
As alike as (two) peas in a pod - похожие как две капли воды - The twins are as alike as two peas in a pod.^\
As easy as ABC - лёгкий, элементарный - This rule is as easy as ABC^\
At first glance - на первый взгляд - He appeared quite healthy at first glance.^\
At hand - близко, под рукой - With the holiday season at hand, everyone is very excited.^\
At loggerheads (with someone) - в ссоре - Mr. and Mrs. Franklin have been at loggerheads for years.^\
At loose ends - безработный, свободный - Jane has been at loose ends ever since she lost her job.^\
At one’s wit’s end - в замешательстве - Tom could do no mo re. He was at his w it’s end.^\
At random - наугад - Sally picked four names at random from the telephone book.^\
At sixes and sevens - растерянный - Bill is always at sixes and sevens when he’s home by himself.^\
At stake - на кону - That’s a very risky investment. How much money is at stake?^\
At the back of one's mind - подсознательно - At the back of my mind I hoped that he was alive^\
At the bottom of the ladder - на нижней ступеньке (о работе) - When Ann got fired, she had to start all over again at the bottom of the ladder.^\
At the break of dawn at - на рассвете - The birds start singing at the break of dawn.^\
At the eleventh hour - в последний момент - We don’t worry about death until the eleventh hour.^\
At the mercy of someone - по милости - We were left at the mercy of the arresting officer.^\
At times - иногда - At times, I wish I had never come here.^\
At will - по желанию - You can eat anything you want at will.^\
Attic salt - тонкая шутка - Bill is well-knoun for his Attic salts.^\
Avenue of escape - путь отступления - Bill saw that his one avenue of escape was through the back door.^\
Avoid someone or something like the plague - избегать как чумы - I don’t like opera. I avoid it like the plague.^\
Awkward as a cow on a crutch / awkward as a cow on roller skates - как корова на льду - When Lulu was pregnant, she was awkward as a cow on a crutch.^\
Babe in the woods - наивный, невинный - Bill is a babe in the woods when it comes to dealing with plumbers.^\
Babes and sucklings - новачки, неопытные люди - We are all babes and sucklings in this sphere.^\
Baby car - малолитражный автомобиль - Jane adores her baby car.^\
Baby moon - искуственный спутник Земли - I'd like to see a baby moon one day^\
Back and forth - туда- сюда - The young man was pacing back and forth in the hospital waiting room.^\
Back down (from someone or something) - отказываться, отступать - It’s probably better to back down from someone than to have an argument^\
Back of the beyond - очень отдалённое место - John hardly ever comes to the city. He lives at the back of the beyond.^\
Back someone or something up - поддерживать - Please back me up in this argument^\
Back the wrong horse - поддерживать не того кандидата, просчитаться - Fred backed the wrong horse in the budget hearings.^\
Bad blood (between people) - враждебность - There is no bad blood between us. I don’t know why we should quarrel.^\
Bad egg - вор, мошейник, никчемный человек - He is a bad egg, he should be sent to the prison long ago.^\
Bad-mouth someone or something - ругать, проклинать - Mr. Smith was always badmouthing Mrs. Smith. They didn’t get along.^\
Bag and baggage - со всеми пожитками - Sally showed up at our door bag and baggage one Sunday morning.^\
Bag of wind - говорун, трепло - She is a real bag of wind.^\
Bail out (of something) - прыгнуть с парашютом, бросить что-либо - John still remembers the first time he bailed out of a plane.^\
Bail someone or something out - поручиться, выкупить кого-либо - John was in jail. I had to go down to the police station to bail him out.^\
Baker's dozen - чертова дюжина - We were asked to bring the baker's dozen of eggs.^\
Balance the accounts - свести счеты - Tom hit Bob. Bob balanced the accounts by breaking Tom’s toy car.^\
Bald as a coot - Лысый как колено - If Tom’s hair keeps receding like that, he’ll be bald as a coot by the time he’s thirty.^\
Ball and chain - ноша, тяжелая обязанность - Tom wanted to quit his job. He said he was tired of that old ball and chain.^\
Ball of fire - трудоголик, очень энергичный человек - Sally is a real ball of fire—she works late every night.^\
Bank holiday - праздничный выходной день, когда закрыты все учереждения - Christmas and Easter are bank holidays in Britain.^\
Baptism of fire - крещение огнём, первый опыт - My son’s just had his first visit to the dentist. He stood up to the baptism of fire very well^\
Bare as the palm of one's hand - пусто, как на ладони; абсолютно пустой - His house was bare as the palm of his hand.^\
Bark up the wrong tree - ошибиться, сделать неправильный выбор - If you think I’m the guilty person, you’re barking up the wrong tree.^\
Batten down the hatches - готовиться к трудным временам - Batten down the hatches, Congress is in session again.^\
Bawl someone out - выругать кого-либо - The teacher bawled the student out for arriving late.^\
Be a million miles away - быть отвлеченным, замечтаться - You were a million miles away while I was talking to you.^\
Be a new one on someone - новость, в которую тяжело поверить - Jack’s poverty is a new one on me. He always seems to have plenty of money.^\
Be about something - быть занятым чем-либо - It’s eight o’clock, and it’s time I was about my homework.^\
Be addicted to - иметь вредные привычки - He is addicted to alcohol and drugs.^\
Be all ears - внимательно слушать - Be careful what you say. The children are all ears.^\
Be all eyes (and ears) - быть настороженным, внимательно смотреть и слушать - Nothing can escape my notice. I’m all eyes and ears.^\
Be at one's wit’s end - быть в растерянности - Mary was at her wit’s end whether to tell her husband about the incident or not.^\
Be badly off - быть в сложном положении, нуждаться - I was badly off, but nobody helped me.^\
Be curtains for someone or something - конец, смерть, банкротство - If the car hadn’t swerved, it would have been curtains for the pedestrians^\
Be flying high - летать высоко, быть успешным - Wow! Todd is really f lying high. Did he discover a gold mine?^\
Be from Missouri - требовать доказательства - You’l l have to prove it to me. I ’m from Missouri.^\
Be in the air - \" висеть в воздухе\", носиться в воздухе - Rumours are in the air.^\
Be laid up - быть прикованным к постели, болеть - Professor Carson had to cancel his class because he was laid up with the flu.^\
Be of an age - достичь возраста - He is of an age when he ought to try settling down.^\
Be on the anxious seat - сидеть как на иголках - Not knowing the answer she was on the anxious seat^\
Be swimming in something - утопать в чем-либо - The war-torn city was swimming in blood.^\
Be the last straw - быть последней каплей - When Sally came down sick, that was the straw that broke the camel’s back.^\
Be the spitting image of someone - быть точной копией кого-то - John is the spitting image of his father.^\
Bear a grudge (against someone) - иметь зуб на кого-то - How long can a person hold a grudge? Let’s be friends.^\
Bear the brunt (of something) - принимать удар на себя - Why don’t you talk with her the next time? I’m tired of bearing the brunt.^\
Bear with someone or something - быть терпеливым - Please bear with my old car. It’ll get us there sooner or later.^\
Beard the lion in his den - смело идти навстречу опасности - I went to the tax collector’s office to beard the lion in his den.^\
Beat a (hasty) retreat - быстро вернуться назад - We went out into the cold weather, but beat a retreat to the warmth of our fire.^\
Beat a dead horse - продолжать ненужный спор - Stop arguing! You have won your point. You are just beating a dead horse.^\
Beat a path to someone’s door - проложить тропу, часто приходить - If you really become famous, people will beat a path to your door.^\
Beat around the bush , beat about the bush - растекаться мозгами по древу, говорить попусту - Stop beating around the bush and answer my question.^\
Beat one’s brains out (to do something) - ломать голову над чем-то - That’s the last time I’ll beat my brains out trying to cook a nice dinner for you.^\
Beat one’s head against the wall / bang one’s head against a brick wall - биться головой об стену - You’re wasting your time trying to fix up this house. You’re just beating your head against the wall.^\
Beat someone down (to size) /knock someone down (to size) - усмирить кого-либо - If you keep acting so arrogant, someone is going to beat you down to size.^\
Beat someone to the punch / beat someone to the draw - сделать что-либо раньше других - I planned to write a book about computers, but someone else beat me to the draw.^\
Beat something into someone’s head - вбить в голову - I studied for hours. I have never beat so much stuff into my head in such a short time.^\
Beat the air - толочь воду в ступе - Don't beat the air, you can't help him^\
Beat the clock - закончить до крайнего срока - Sam beat the clock, arriving a few minutes before the doors were locked.^\
Beat the gun - успеть до окончания срока - Tom tried to beat the gun, but he was one second too slow.^\
Beat the living daylights out of someone /beat the stuffing out of someone/ beat the tar out of someone/ whale the tar out of someone - побить, выбить душу - The last time Bobby put the cat in the refrigerator, his mother beat the living daylights out of him.^\
Beat the pants off someone - 1 побить физически; 2 выиграть - Tom beats the pants off Bob when it comes to writing poetry^\
Beat the rap - избежать наказания - The police hauled Tom in and charged him with a crime. His lawyer helped him beat the rap.^\
Bed of roses - лёгкая жизнь - Living with Pat can’t be a bed of roses, but her husband is always smiling.^\
Beef something up - усиливать - The government decided to beef the army up by buying hundreds of new tanks.^\
Before you can say Jack Robinson - очень быстро - I’ll catch a plane and be there before you can say Jack Robinson.^\
Beg the question - спорный вопрос - His complaints beg the question: Didn’t he cause all of his problems himself ?^\
Beg to differ (with someone) - позволить себе не согласиться - I beg to differ with you, but you have stated everything exactly backwards.^\
Begin to see daylight - увидеть просветление, приближаться к завершению - I’ve been working on my thesis for two years, and at last I’m beginning to see daylight.^\
Beginning of the end - начало конца - The enormous federal deficit marked the beginning of the end as far as our standard of living is concerned.^\
Behind closed doors - за закрытыми дверями, тайно - They held the meeting behind closed doors, as the law allowed.^\
Behind one's back - тайно, без ведома - Please don’t talk about me behind my back.^\
Behind schedule - отставать от графика - The project is behind schedule. Very late, in fact.^\
Behind someone’s back - за спиной, тайно - She sold the car behind his back.^\
Behind the eight ball - неприятная ситуация - I ran over the neighbor’s lawn with my car, so I’m really behind the eight ball.^\
Behind the scenes - за кулисами - We don’t usually thank the people who are behind the scenes.^\
Behind the times - старомодный - Sarah is a bit behind the times. Her clothes are quite old-fashioned.^\
Below par - хуже обычного - I feel a little below par today. I think I am getting a cold.^\
Bend someone’s ear - висеть на ушах (надоедливо говорить) - Tom is over there, bending Jane’s ear about something.^\
Bent on doing something - быть обязанным - Her mother was bent on keeping her at home.^\
Beside oneself (with something) - вне себя - Sarah could not speak. She was beside herself with anger.^\
Beside the point / beside the question - не относится к теме - That’s very interesting, but beside the point.^\
Best bib and tucker - лучшая одежда - I always wear my best bib and tucker on Sundays.^\
Best-laid plans of mice and men / the best-laid schemes of mice and men - продуманный план - If a little rain can ruin the best-laid plans of mice and men, think what an earthquake might do!^\
Bet one’s bottom dollar / bet one’s life - спорим; быть уверенным - I bet my bottom dollar you can’t swim across the pool.^\
Between life and death - между жизнью и смертью - And there I was on the operating table, hovering between life and death.^\
Between you, me, and the lamppost - между нами говоря - Just between you, me, and the lamppost, Fred is leaving school.^\
Betwixt and between - не то, не сё - Tom is so betwixt and between about getting married. I don’t think he’s ready.^\
Beyond all doubt - вне всякого сомнения - He is the best student in the group,beyond all doubt^\
Beyond the shadow of a doubt - без тени сомнения - We accepted her story as true beyond the shadow of a doubt.^\
Beyond words - не высказать словами - I don’t know how to thank you. I’m grateful beyond words.^\
Bid adieu to someone or something / bid someone or something adieu - попрощаться - Now it’s time to bid adieu to all of you gathered here.^\
Bide one’s time - терпеливо ждать - I’ve been biding my time for years, just waiting for a chance like this.^\
Big and bold [of things] - привлекающий внимание - The lettering on the book’s cover was big and bold, and it got lots of attention, but the price was too high.^\
Big bug/big shot/bigwig - большой человек, \"шишка\" - He was a big bug in this business.^\
Big frog in a small pond - \"большая лягушка в маленьком пруду\" - The trouble with Tom is that he’s a big frog in a small pond. He needs more competition.^\
Big moment / the moment everyone has been waiting for - выдающийся момент - The big moment has come. I will now announce the winner.^\
Big of someone - очень щедро - He gave me some of his apple. That was very big of him.^\
Binge and purge - переедать и вызывать рвоту - She had binged and purged a number of times before she finally sought help from a doctor.^\
Birds and the bees - процесс воспроизведения человека (секс) - My father tried to teach me about the birds and the bees.^\
Bite off more than one can chew - брать на себя больше, чем можешь сделать - Ann is exhausted again. She’s always biting off more than she can chew.^\
Bite one’s nails - кусать ногти, очень переживать - I spent all afternoon biting my nails, worrying about you.^\
Bite one’s tongue - прикусить язык - I had to bite my tongue to keep from telling her what I really thought.^\
Bite someone’s head off - говорить резко, со злостью - There was no need to bite Mary’s head off just because she was five minutes late.^\
Bite the bullet - смириться, вынести что-либо - I didn’t want to go to the doctor, but I bit the bullet and went.^\
Bite the dust - умереть - Poor old Bill bit the dust while mowing the lawn. They buried him yesterday.^\
Bite the hand that feeds one - кусить руку, которая кормит - I’m your mother! How can you bite the hand that feeds you?^\
Bitter pill to swallow - горькая пилюля, неприятный факт - We found his deception a bitter pill to swallow.^\
Black as coal - черный как уголь - The stranger’s clothes were all black as coal.^\
Black out - потерять сознание - I was so frightened that I blacked out for a minute.^\
Black-and-blue - избитый - The child was black-and-blue after having been struck.^\
Bleep something out - заменить слова музыкой, \"запикать\" - He tried to say the word on television, but they bleeped it out.^\
Blessing in disguise - нет лиха без добра - Our missing the train was a blessing in disguise. It was involved in a crash.^\
Blind as a bat - слепой - I’m getting blind as a bat. I can hardly read this page.^\
Blood, sweat, and tears - кровь, пот и слёзы - After years of blood, sweat, and tears, Timmy finally earned a college degree.^\
Blow a gasket ; blow a fuse; blow one’s cork; blow one’s top; blow one’s stack - разгневаться - I was so mad I almost blew a gasket.^\
Blow someone or something to smithereens - разнести в клочья - The bomb blew the ancient church to smithereens.^\
Bone of contention - яблоко раздора, причина ссоры - We’ve fought for so long that we’ve forgotten what the bone of contention is.^\
Bone up (on something) - зубрить, учить - I have to bone up on the state driving laws because I have to take my driving test tomorrow.^\
Bore someone stiff ; bore someone to death - надоесть до смерти - The play bored me stiff.^\
Born out of wedlock - рождённый вне брака - In the city many children are born out of wedlock.^\
Born with a silver spoon in one’s mouth - родиться в богатой семье - Sally was born with a silver spoon in her mouth.^\
Borrow trouble - навлекать неприятности - Do not get involved with politics. That’s borrowing trouble.^\
Boss someone around - командовать - Stop bossing me around. I’m not your employee.^\
Bottle something up - закупорить, держать в себе - The police bottled up the traffic while they searched the cars for the thieves.^\
Bottom line - нижняя черта, крайний срок - I know about all the problems, but what is the bottom line? What will happen?^\
Bottom out - достичь дна - The price of wheat bottomed out last week. Now it’s rising again.^\
Bottoms up! - поднять бокалы, выпить - Here’s to the bride and groom. Bottoms up!^\
Bow and scrape - раболепствовать - The salesclerk came in, bowing and scraping, and asked if he could help us.^\
Bread-and-butter letter - письмо благодарности - When I got back from the sales meeting, I took two days to write bread-and-butter letters to the people I met.^\
Break (out) in(to) tears - расплакаться - I was so sad that I broke out into tears.^\
Break new ground - начинать что-либо, быть пионером в чем-либо - Dr. Anderson was breaking new ground in cancer research.^\
Break off (with someone) - разойтись с кем-либо - Tom has finally broken off with Mary.^\
Break one’s neck (to do something) / break one’s back (to do something) - тяжело работать - I broke my neck to get here on time.^\
Break out in a cold sweat - испугаться, бросить в холодный пот - I was so frightened I broke out in a cold sweat.^\
Break someone or something up - разсмешить; завершить; разбить - John told a joke that really broke Mary up.^\
Break someone’s fall - смягчить падение - When the little boy fell out of the window, the bushes broke his fall.^\
Break someone’s heart - разбить сердце - Sally broke John’s heart when she refused to marry him.^\
Break something to pieces - разбить вдребезги - I dropped a glass and broke it to pieces.^\
Break something to someone - сообщить плохую новость - Bill broke it to his employees gently.^\
Break the back of something - прекратить доминирование чего-либо - The government has worked for years to break the back of organized crime.^\
Break the bank - истратить все деньги - Buying a new dress at that price won’t break the bank.^\
Break the ice - начать общение - Tom is so outgoing. He’s always the first one to break the ice at parties.^\
Breaking and entering - взлом с проникновением - Max was charged with four counts of breaking and entering.^\
Breath of fresh air - глоток свежего воздуха - Sally, with all her wonderful ideas, is a breath of fresh air.^\
Breathe down someone’s neck - дышать в шею; преследовать - I have to finish my taxes today. The tax collector is breathing down my neck.^\
Breathe one’s last - сделать последний вдох; умереть - Mrs. Smith breathed her last this morning.^\
Brew a plot - составить заговор - The children brewed an evil plot to get revenge on their teacher.^\
Bricks and mortar - строения, постройки - Sometimes people are happy to donate millions of dollars for bricks and mortar, but they never think of the additional cost of annual maintenance.^\
Bright as a new pin - сиять как новый пятак - My kitchen f loor is bright as a new pin since I started using this new f loor wax.^\
Bright-eyed and bushy-tailed - в хорошем расположении духа - She appeared at the top of the stairs, bright-eyed and bushy-tailed, ready to start the day.^\
Brimming with something - светящийся от счастья или других эмоций - The giggling children were brimming with joy.^\
Bring home the bacon - зарабатывать деньги - I’ve got to get to work if I’m going to bring home the bacon.^\
Bring people or other creatures out in droves - заманивать, соблазнять - The availability of free drinks brought people out in droves.^\
Bring something home to someone - осознать - Seeing the starving refugees on television really brings home the tragedy of their situation.^\
Bring something to light - представить - The scientists brought their findings to light.^\
Broad in the beam - быть широким в тазу - I am getting a little broad in the beam. It’s time to go on a diet.^\
Brush up (on something) - повторить, освежить в памяти - I think I should brush up on my Spanish before I go to Mexico.^\
Buck for something - стремиться - Tom is bucking for a larger office.^\
Buckle down (to something) - взяться за работу - If you don’t buckle down to your job, you’ll be fired.^\
Bug out - уйти, убраться - I just got a call from headquarters. They say to bug out immediately.^\
Bug someone - раздражать - Go away! Stop bugging me!^\
Build a case (against someone) /assemble a case (against someone)/ gather a case (against someone) - выстроить дело - The police easily built a case against the drunken driver.^\
Build a fire under someone - заставить кого-либо делать что-то - The teacher built a fire under the students, and they really started working.^\
Build castles in the air / build castles in Spain - мечтать - I really like to sit on the porch in the evening, just building castles in the air.^\
Build something to order - делать на заказ - Our new car was built to order just for us.^\
Bull in a china shop - очень неуклюжий, слон в посудной лавке - Look at Bill, as awkward as a bull in a china shop.^\
Bump into someone / run into - случайно встретиться - Guess who I bumped into downtown today?^\
Bump someone off / knock someone off - убить - The crooks bumped off the witness to the crime.^\
Bundle of nerves - взволнованый человек, пучек нервов - Mary was a bundle of nerves until she heard that she passed the test.^\
Burn one’s bridges (behind one) - сжечь за собой мосты - If you drop out of school now, you’ll be burning your bridges behind you.^\
Burn someone at the stake - сжечь на столбе, строго наказать кого-то - Stop yelling. I made a simple mistake, and you’re burning me at the stake for it.^\
Burn someone in effigy - сжечь чьё-либо изображение или куклу в знак ненависти - Until they have burned you in effigy, you can’t really be considered a famous leader.^\
Burn someone or something to a crisp - сжечь на золу - The flames burned him to a crisp.^\
Burn the candle at both ends - усердно работать, засиживаясь до поздна - No wonder Mary is ill. She has been burning the candle at both ends for a long time.^\
Burn the midnight oil - усердно работать, засиживаясь до поздна - If you burn the midnight oil night after night, you’ll probably become ill.^\
Burn to ashes - сгореть до тла - The house was burned to ashes.^\
Burn with a low blue flame - быть очень злым - By the time she showed up three hours late, I was burning with a low blue flame.^\
Burned to a cinder - сильно обгореть - I stayed out in the sun too long, and I am burned to a cinder.^\
Burst at the seams - \"лопнуть по швам\", лопнуть от смеха, гордости - Tom nearly burst at the seams with pride.^\
Burst into tears / burst out crying - расплакаться - After the last notes of her song, the audience burst into tears, such was its beauty and tenderness.^\
Burst out laughing - разразиться смехом - The entire audience burst out laughing at exactly the wrong time, and so did the actors.^\
Burst someone’s bubble - разрушить иллюзии - I hate to burst your bubble, but Columbus did not discover Canada.^\
Burst with pride - лопнуть от гордости - I almost burst with pride when I was chosen to go up in the space shuttle.^\
Bury one’s head in the sand / hide one’s head in the sand - прятать голову в песок, игнорировать опастность - Stop burying your head in the sand. Look at the statistics on smoking and cancer.^\
Bury the hatchet - закопать топор войны - I wish Mr. and Mrs. Franklin would bury the hatchet. They argue all the time.^\
Busman’s holiday - свободное время, которое человек проводит занимаясь тем, что не отличается от его работы - Tutoring students in the evening is too much of a busman’s holiday for our English teacher.^\
Bust a gut (to do something) - надрывать кишки - I busted a gut to get there the last time, and I was the first one there.^\
Busy as a bee - очень занятой - Whenever there is a holiday, we are all as busy as bees getting things ready^\
Busy as a bee - очень занятой - Whenever there is a holiday, we are all as busy as bees getting things ready.^\
Butt in (on someone or something) - перебивать кого-то, прерывать что-то - Pardon me for butting in on your conversation, but this is important.^\
Butter someone up - \"подмазывать\", хвалить кого-то - I believe my landlady prefers for me to butter her up rather than getting the rent on time.^\
Button one’s lip - закрыть рот на замок - All right now, let’s button our lips and listen to the story.^\
Buy a pig in a poke - купить кота в мешке - Buying a car without test-driving it is like buying a pig in a poke.^\
Buy something for a song - купить что-то очень дёшево - No one else wanted it, so I bought it for a song.^\
Buy something to go / get something to go/ have something to go/ order something to go to - купить что-либо на вынос - Let’s stop here and buy six hamburgers to go.^\
By a hair(‘s breadth) / by a whisker - едва - I just missed getting on the plane by a hair’s breadth.^\
By guess and by golly - благодаря удаче - They managed to get the shed built by guess and by golly.^\
By hook or (by) crook - любым способом (законным и противозаконным) - I must have that house. I intend to get it by hook or crook.^\
By leaps and bounds - гигантскими скачками, большими темпами - The profits of my company are increasing by leaps and bounds.^\
By shank’s mare - пешком - My car isn’t working, so I’ll have to travel by shank’s mare.^\
By the seat of one’s pants - без уменья, благодаря удаче - The jungle pilot spent most of his days f lying by the seat of his pants.^\
Call (the) roll / take (the) roll - сделать перекличку - After I call the roll, please open your books to page 12.^\
Call a spade a spade - называть своими именами - Well, I believe it’s time to call a spade a spade. We are just avoiding the issue.^\
Call it a day - закончить работу и уйти домой - The boss was mad because Tom called it a day at noon and went home.^\
Call it quits - отказаться, уволиться - Okay! I’ve had enough! I’m calling it quits.^\
Call of nature - \"зов природы\", необходимость пойти в туалет - Stop the car here! I have to answer the call of nature.^\
Call someone down - выругать - The teacher had to call Sally down in front of everybody.^\
Call someone names - обзываться - Mommy! John is calling me names again!^\
Call someone on the carpet - \"вызватьна ковёр\", отчитать кого-то - One more error like that and the boss will call you on the carpet.^\
Call the shots / call the tune - принимать решения - Sally always wants to call the shots, and Mary doesn’t like to be bossed around. They don’t get along well.^\
Calm as a toad in the sun - совершенно спокойный - Nothing ruff les him. He’s calm as a toad in the sun.^\
Can't (can) afford - позволить себе ( в материальном плане) - I can't afford to buy this expensive car.^\
Cannot help doing something - не могу не - Anne is such a good cook, I can’t help eating everything she makes.^\
Can’t hold a candle to someone - быть неравным, не иметь возможности оценить что-то - Mary can’t hold a candle to Ann when it comes to auto racing.^\
Can’t make heads or tails (out) of someone or something - не понимать что-либо, не разобрать - Do this report again. I can’t make heads or tails out of it.^\
Can’t see beyond the end of one’s nose - не видеть дальше своего носа, быть не состоянии спланировать что-либо - John is a very poor planner. He can’t see beyond the end of his nose.^\
Can’t stand (the sight of) someone or something / can’t stomach someone or something - тарпеть не могу, не могу переваривать - I can’t stand the sight of cooked carrots.^\
Can’t wait (for something to happen) - ожидать с нетерпением - I am so anxious for my birthday to come. I just can’t wait.^\
Cap and gown - академическая мантия - I appeared wearing my cap and gown, but I had shorts on underneath because it gets so hot at that time of year.^\
Carry a secret to the grave / carry a secret to one’s grave - унести тайну в могилу - Trust me, I will carry your secret to the grave!^\
Carry a torch (for someone) - быть безнадёжно влюблённым - John is carrying a torch for Jane.^\
Carry coals to Newcastle - делать что-либо ненужное - Taking food to a farmer is like carrying coals to Newcastle.^\
Carry one’s (own) weight / pull one’s (own) weight - делать свою часть работы - Tom, you must be more helpful around the house. We all have to carry our own weight.^\
Carry one’s cross - нести свой крест - I can’t help you with it. You’ll just have to carry your cross.^\
Carry the bag - распоряжаться деньгами, быть хозяином положения - In our family the mother carries the bag.^\
Carry the weight of the world on one’s shoulders - нести тяжесть мира на своих плечах - Look at Tom. He appears to be carrying the weight of the world on his shoulders.^\
Cash in (on something) - заработать много денег - This is a good year for farming, and you can cash in on it if you’re smart.^\
Cash in one’s chips - умереть - Bob cashed in his chips yesterday^\
Cash on the barrelhead - деньги, потраченные во время распродажи, небольшие деньги - I paid $12,000 for this car—cash on the barrelhead.^\
Cash-and-carry - платить наличными и забирать товар - Sorry, we don’t accept credit cards. This is strictly cash-and-carry.^\
Cast (one’s) pearls before swine - метать бисер перед свиньями; делать то, что не будет оценено - To serve them French cuisine is like casting one’s pearls before swine.^\
Cast around for someone or something / cast about for someone or something - подыскивать кого-то, либо что-то - John is casting around for a new cook. The old one quit.^\
Cast aspersions on someone - делать грубые и обижающие комментарии - I resent your casting aspersions on my brother and his ability!^\
Cast the first stone - бросить первым камень, быть первым, кто начинает критиковать - Well, I don’t want to be the one to cast the first stone, but she sang horribly.^\
Catch cold / take cold - заболеть - Please close the window or we’ll all catch cold.^\
Catch forty winks / catch some Zs/ take forty winks - уснуть, вздремнуть - I’ll just catch forty winks before getting ready for the party.^\
Catch one with one’s pants down - поймать на горячем - John couldn’t convince them he was innocent. They caught him with his pants down.^\
Catch someone red-handed - поймать на горячем - Tom was stealing the car when the police drove by and caught him red-handed.^\
Catch up (to someone or something) / catch up (with someone or something) - сравняться, догнать кого-либо/что-либо - The red car caught up with the blue one.^\
Catch-as-catch-can - лучшее из имеющегося - We went hitchhiking for a week and lived catch-as-catch- can.^\
Cause (some) tongues to wag - дать повод для сплетен - The way John was looking at Mary will surely cause some tongues to wag.^\
Champ at the bit / chomp at the bit - ждать с нетерпением - The dogs were champing at the bit to begin the hunt.^\
Change hands - менять собственника - How many times has this house changed hands in the last ten years?^\
Change horses in the middle of the stream - менять коней на переправе - The house is half-built. It’s too late to hire a different architect. You can’t change horses in the middle of the stream.^\
Change of pace - изменить обстановку - The doctor says I need a change of pace.^\
Change someone’s mind - поменять мнение - I can change my mind if I want to. I don’t have to stick with an idea.^\
Change the subject - поменять тему разговора - They changed the subject suddenly when the person whom they had been discussing entered the room.^\
Cheat on someone - обманывать, изменять любимому - “Have you been cheating on me?” cried Mrs. Franklin.^\
Checks and balances - система противовеса - The newspaper editor claimed that the system of checks and balances built into our Constitution has been subverted by party politics.^\
Cheek by jowl - бок о бок - The pedestrians had to walk cheek by jowl along the narrow streets.^\
Cheer someone on - поддерживать кого-либо - John was leading in the race, and the whole crowd was cheering him on.^\
Cheesed off - расстроеный, в плохом настроении - He was cheesed off with his job.^\
Chew someone out / eat someone out - \"съесть кого-либо\", ругать кого-либо - The boss is always chewing out somebody.^\
Chew the fat / chew the rag - неформально общаться, болтать - Hi, old buddy! Come in and let’s chew the fat.^\
Chicken out (of something) - струсить - Jane was going to go parachuting with us, but she chickened out at the last minute.^\
Child’s play - очень лёгкое задание - The test was child’s play to her.^\
Chilled to the bone - промерзать до костей - The children were chilled to the bone in the unheated room.^\
Chink in one’s armor - брешь в броне, слабое место - His love for his child is the chink in his armor.^\
Chip in (on something) / chip in something on something/ chip something in (on something) - сбрасываться деньгами, давать небольшую сумму денег на какие-либо цели - Would you care to chip in on a gift for the teacher?^\
Chisel someone out of something - обманывать кого-то, чтобы завладеть деньгами или имуществом - The company tried to chisel the government out of taxes it owed.^\
Choke someone up - растрогать до слёз - The sight of all those smiling people choked Bob up, and he couldn’t go on speaking.^\
Clam up - закрыть рот - You talk too much, John. Clam up!^\
Clean as a hound’s tooth - чистый, невиновный - John had faith that he would not be convicted for the robbery, since he had been clean as a hound’s tooth since getting out of prison.^\
Clean as a whistle - чистый - I thought the car would be filthy, but it was as clean as a whistle.^\
Clear as a bell - четкий, ясный - Through the wall, I could hear the neighbors talking, just as clear as a bell.^\
Clear as crystal - прозрачный, понятный - She cleaned the windowpane until it was clear as crystal.^\
Clear as mud - неясный, непонятный - This doesn’t make sense. It’s clear as mud.^\
Clear someone’s name - оправдать кого-либо - I was accused of theft, but I cleared my name.^\
Climb the wall(s) - \"лезь на стену\" - The meeting was so long and the speaker so boring that most of the audience wanted to climb the wall.^\
Clip someone’s wings - \"подрезать крылья\", ущемить в привилегиях, приструнить кого-то - You had better learn to get home on time, or I will clip your wings.^\
Cloak-and-dagger - секретный, связаный с интригами - A great deal of cloak-and-dagger stuff goes on in political circles.^\
Close as two coats of paint - близкие люди, закадычные друзья - When Tom and Mary were kids, they were as close as two coats of paint.^\
Close one’s eyes to something - закрывать глаза на что-то - You can’t close your eyes to hunger in the world.^\
Close shave - почти неминуемая гибель - Staying in the mountains was a close shave for him.^\
Close up shop - закончить работу - I can’t make any money in this town. The time has come to close up shop and move to another town.^\
Cloud up - нахмуриться - The baby clouded up and let out a howl.^\
Clue someone in (on something) - проинформировать - Please clue me in on what’s going on.^\
Clutch at straws - хвататься за соломинку, продолжать попытки решить что-либо - That is not a real solution to the problem. You are just clutching at straws.^\
Cock of the walk - петушиться - The deputy manager was cock of the walk until the new manager arrived.^\
Cock-and-bull story - глупая, придуманая история - I asked for an explanation, and all I got was your ridiculous cock-and-bull story!^\
Cocky as the king of spades - горд собой - She strutted in, cocky as the king of spades.^\
Coffee-table book - книга, в которой оформление лучше, чем содержание - This book is more of a coffee-table book than an art book. I prefer something more scholarly.^\
Cold as a witch’s caress - очень холодный, пугающий - She gave me a look as cold as a witch’s caress.^\
Cold comfort - слабое утешение - She knows there are others worse off than she is, but that’s cold comfort.^\
Cold fish - неэмоциональный, холодный человек - She hardly ever speaks to anyone. She’s a cold fish.^\
Cold, hard cash - наличность, не чек и не карточка - I want to be paid in cold, hard cash, and I want to be paid now!^\
Come a cropper - провалиться, потерпеть неудачу - Bob invested all his money in the stock market just before it fell. Boy, did he come a cropper.^\
Come along! - идём (вместе)!^\
Come apart at the seams - потерять контроль над эмоциями - Bill was so upset that he almost came apart at the seams.^\
Come away empty-handed - вернуться не с чем - All right, go gambling. Don’t come away empty-handed, though.^\
Come clean (with someone) - сознаться - All right, I’ll come clean. Here is the whole story.^\
Come down in the world - потерять социальное положение - Mr. Jones has really come down in the world since he lost his job.^\
Come down to earth - спутиться с небес на землю, быть реалистом - You have very good ideas, John, but you must come down to earth. We can’t possibly afford any of your suggestions.^\
Come down with something - слечь с чем-либо - I’ll probably come down with pneumonia.^\
Come from nowhere - появиться из ниоткуда - The whole set of problems came from nowhere. There was no way we could have foreseen them.^\
Come full circle - вернуться на изначальное положение - The family sold the house generations ago, but things have come full circle and one of their descendants lives there now.^\
Come hell or high water - будь что будет - Come hell or high water, I intend to have my own home.^\
Come home to someone - осознать - The truth of the matter suddenly came home to me.^\
Come in a body / arrive in a body - появиться группой - All the guests came in a body.^\
Come in handy - быть полезным или удобным в использовании - A small television set in the bedroom would come in handy.^\
Come in out of the rain - вернуться с небес на землю - Bill will fail if he doesn’t come in out of the rain and study.^\
Come into one’s own and come into its own - получить признание - After years of trying, she finally came into her own.^\
Come off one's feet - оторваться ногами - To our astonishment, he almost came off his feet.^\
Come off second-best - получить второе место, прийти вторым - John came off second-best in the race.^\
Come on like gangbusters - вести себя очень грубо - Why is she so unpolished? She comes on like gangbusters and frightens people away.^\
Come out (of the closet) - признаться в тайных интересах; признать свою гомосексуальность - Tom Brown came out of the closet and admitted that he likes to knit.^\
Come out ahead - завершить с прибылью, улучшить ситуацию - I hope you come out ahead with your investments.^\
Come out in the wash - всё будет хорошо - Don’t worry about that problem. It’ll all come out in the wash.^\
Come out of left field - появиться откуда не ждали - This new problem came out of left field. We were really surprised.^\
Come out of one’s shell - быть более дружелюбным, общительным; вылезти из скорлупы - Ann, you should come out of your shell and spend more time with your friends.^\
Come out of the blue - внезапно возникнуть, упасть с неба - This idea came out of the blue, and I think it is a good one.^\
Come through something with flying colors - успешно перенести, пережить что-то - Todd came through the test with f lying colors.^\
Come to a bad end - плохо закончить - My old car came to a bad end. Its engine burned up.^\
Come to a dead end - зайти в тупик - The building project came to a dead end.^\
Come to a head - дойти до точки, когда проблему нужно решать; дойти до края - Remember my problem with my neighbors? Well, last night the whole thing came to a head.^\
Come to a standstill - остановиться временно или постоянно - The party came to a standstill until the lights were turned on again.^\
Come to an end - закончиться - The party came to an end at midnight.^\
Come to grips with something - осознать, понять, смириться - Many students have a hard time coming to grips with algebra.^\
Come to light - стать известным другим людям, открыться - Some interesting facts about your past have just come to light.^\
Come to mind - прийти в голову - Do I know a good barber? No one comes to mind right now.^\
Come to nothing / come to naught - сойти на нет, уменьшиться до нуля - So all my hard work comes to nothing.^\
Come to one’s senses - прийти в себя, очнуться - In the morning I don’t come to my senses until I have had two cups of coffee.^\
Come to terms with someone or something - договориться - I finally came to terms with my lawyer about his fee.^\
Come to the fore - стать знаменитым, важным - Since his great showing in court, my lawyer has really come to the fore in city politics.^\
Come to the point / get to the point - перейти к делу - He has been talking a long time. I wish he would come to the point.^\
Come to think of it - я вспомнил... - Come to think of it, I know someone who can help.^\
Come true - сбыться - When I got married, all my dreams came true.^\
Come what may - будь что будет - I’ll be home for the holidays, come what may.^\
Comfortable as an old shoe - очень удобный - That’s a great tradition—comfortable as an old shoe.^\
Common as dirt - вульгарный, с плохими манерами - Despite Jane’s efforts to imitate the manners of the upper class, the town’s leading families still considered her common as dirt.^\
Con someone out of something - выманить что-либо ценное - Dave conned me out of my autographed baseball.^\
Conceited as a barber’s cat - самодовольный - Ever since he won that award, he’s been as conceited as a barber’s cat.^\
Conk out - сдохнуть (о вещах), поломаться - I hope my computer doesn’t conk out.^\
Control the purse strings - управлять бюджетом - I control the purse strings at our house.^\
Cook someone’s goose - навредить кому-либо - I cooked my own goose by not showing up on time.^\
Cook something up - замыслить, придумать - Mary cooked an interesting party up at the last minute.^\
Cook the accounts - жульничать со счетами, обманывать - Jane was sent to jail for cooking the accounts of her mother’s store.^\
Cooking with gas - делать что-либо правильным образом - Things are moving along nicely with the project. The entire staff is really cooking with gas.^\
Cool as a cucumber - спокойный - During the fire the homeowner was cool as a cucumber.^\
Cool off / cool down - охладеть - TED: Is Bob still in love with Jane? BILL: No, he’s cooled off a lot. TED: I thought that they were both cooling down.^\
Cool one’s heels - ждать кого-либо - I spent all afternoon cooling my heels in the waiting room while the doctor talked on the telephone.^\
Cop a plea - признаться в преступлении, в надежде на смягчение наказазания - The robber copped a plea and got only two years in jail.^\
Cop out - выскользнуть из трудной ситуации - Things were going badly for Senator Phillips, so he copped out by resigning.^\
Copy-book maxims - прописные истины - Not to kill and not to steal are the copy-book maxims^\
Copycat - человек, копирующий поведение другого - Bill is such a copycat. He bought a coat just like mine.^\
Cost a pretty penny - стоить очень дорого - I’ll bet that diamond cost a pretty penny.^\
Cost an arm and a leg - стоить очень дорого - Why should a little plastic part cost an arm and a leg?^\
Cough something up - сделать то, о чем просят, без желания - Bill had to cough up forty dollars to pay for the broken window.^\
Could do with someone or something - хотеть, нуждаться в чем-либо - This house could do with some cleaning up.^\
Count noses - посчитать людей - Everyone is here. Let’s count noses so we can order hamburgers.^\
Cover a lot of ground /cover a lot of territory - проехать большое растояние; охватить большой материал - My car can cover a lot of ground in one day.^\
Cover for someone - прикрыть кого-либо - If I miss class, please cover for me.^\
Cozy up (to someone) - быть слишком любезным с кем-либо, в надежде на особые уступки - Look at that lawyer cozying up to the judge!^\
Crack a book - открыть книгу, учиться (обычно в негативном смысле) - If you think you can get through college without cracking a book, you’re wrong.^\
Crack a joke - шутить - She’s never serious. She’s always cracking jokes.^\
Crack a smile - выдушить улыбку - The soldier cracked a smile at the wrong time and had to march for an hour as punishment.^\
Crack a smile - расплыться в улыбке - On seeing me Joshua cracked a smile.^\
Crank something out - производить что-либо - That factory keeps cranking out cars even though no one buys them.^\
Crazy as a betsy bug - сумашедший - Ever since his w ife le ft him, Joe’s been ac ting as crazy as a betsy bug.^\
Crazy as a peach-orchard boar - сумашедший - What’s wrong with Jim? He’s acting as crazy as a peach-orchard boar.^\
Cream of the crop - лучшее из лучшего - This particular car is the cream of the crop.^\
Create an uproar / make an uproar - производить шум - The dog got into church and made an uproar.^\
Crooked as a barrel of fishhooks - нечестный, подлый - Don’t play cards with him. He’s as crooked as a barrel of fishhooks.^\
Crooked as a dog’s hind leg - подлый, лживый - Mary says all politicians are crooked as a dog’s hind leg.^\
Cross swords (with someone) (on something) - начать спор - I don’t want to cross swords with Tom on this matter.^\
Cross the Rubicon - перейти Рубикон; начать действие, которое неминуемо приведет к черте, за которой нет возврата - Jane crossed the Rubicon by signing the contract.^\
Crux of the matter - сущность проблемы - It’s about time that we looked at the crux of the matter.^\
Cry over spilled milk - плакать над пролитым молоком; грустить о том, что нельзя изменить - I’m sorry that you broke your bicycle, Tom. But there is nothing that can be done now. Don’t cry over spilled milk.^\
Cry wolf - поднимать ошибочную тревогу - Pay no attention. She’s just crying wolf again.^\
Curdle someone’s blood - лединить кровь ( от ужаса, отвращения) - The terrible scream was enough to curdle my blood.^\
Cut a wide swath / cut a big swath - казаться важным; привлекать внимание - In social matters, Mrs. Smith cuts a wide swath.^\
Cut class - пропускать уроки - If Mary keeps cutting classes, she’ll fail the course.^\
Cut from the same cloth / made from the same mold - иметь много общего, быть похожими - She and her brother are cut from the same cloth. They both tell lies all the time.^\
Cut no ice (with someone) - не изменить чьё-либо мнение, не иметь влияния на кого-то - All that may be true, but it cuts no ice with me.^\
Cut one’s (own) throat [for someone] - вредить себе; терпеть поражение - Judges who take bribes are cutting their own throats.^\
Cut one’s eyeteeth on something - иметь большой опыт в чем-либо; делать что-либо с раннего возраста - Do I know about cars? I cut my eyeteeth on cars.^\
Cut out the deadwood - сократить сотрудника, который не приносит пользы - This company would be more profitable if management would cut out the deadwood.^\
Cut out to be something - быть рожденным для какой-либо профессии - Sally was cut out to be a doctor.^\
Cut someone dead - полностью игнорировать кого-либо - Joan was just about to speak to James when he cut her dead.^\
Cut someone down (to size) / take someone down (to size) - поставить кого-либо на место - Jane is too conceited. I think her new boss will cut her down to size.^\
Cut someone off without a penny - оставить без гроша - Mr. and Mrs. Franklin cut their son off without a penny after he quit school.^\
Cut someone or something up - сильно критиковать кого-либо, что-либо - Jane is such a gossip. She was really cutting Mrs. Jones up.^\
Cut someone to the quick - оскорбить чьи-либо чувства - Tom’s sharp words to Mary cut her to the quick.^\
Cut teeth - прорезываться (о зубах) - Ann cut her first tooth this week.^\
Cut the ground out from under someone - выбить почву под ногами - The politician cut the ground out from under his opponent.^\
Cut to the chase - перейти к делу - Let’s stop all this chatter and cut to the chase.^\
Cut up - вести себя плохо; вести себя как клоун - If you spent more time studying than cutting up, you’d get better grades.^\
Daily grind - ежедневная рутина - I’m getting very tired of the daily grind.^\
Damn someone or something with faint praise - косвенно критиковать - The critic did not say that he disliked the play, but he damned it with faint praise.^\
Dance to another tune - изменить поведение, отношение - After being yelled at, Ann danced to another tune^\
Dance with death - танцевать со смертью, рисковать - You are dancing with death in your effort to cross that narrow ledge.^\
Dark horse - тёмная лошадка, неожиданный кандидат - Everyone was surprised at the results of the election. The dark horse won.^\
Dart in and out - метаться - On the highway, a small car was darting in and out of the two right lanes of traffic.^\
Davy Jones’s locker - на дне моря - They were going to sail around the world, but ended up in Davy Jones’s locker.^\
Daylight robbery - вымагательство - The cost of renting a car at that place is daylight robbery.^\
Dead ( stale) air - удушливый воздух - The room had the dead air, because all windows were closed^\
Dead as a dodo - устаревший - That silly old idea is dead as a dodo.^\
Dead as a doornail - мёртвый - This fish is as dead as a doornail.^\
Dead duck - потерпевший неудачу - He missed the exam. He’s a dead duck.^\
Dead in someone’s or something’s tracks - замереть на месте - When I heard the rattlesnake, I stopped dead in my tracks.^\
Dead on its feet / dead on one’s feet - истощенный - Ann is so tired. She’s really dead on her feet.^\
Dead set against someone or something - быть полностью против чего-то - I’m dead set against the new tax proposal.^\
Dead to the world - уставший; тот, кто крепко спит - I’ve had such a hard day. I’m really dead to the world.^\
Deaf as a post - глухой как тетерев - Our old dog is deaf as a post and he can’t see much either.^\
Deem it (to be) necessary / deem that it is necessary - верить, что что-либо является необходимым - Mary deemed that it was necessary to leave town that night.^\
Deep-six someone or something - избавиться от чего-либо - Take this horrible food out and deep-six it.^\
Den of iniquity - пещера зла; лежбище зла - The town was a den of iniquity and vice was everywhere.^\
Desert a sinking ship / leave a sinking ship - покинуть тонущий корабль - There goes Tom. Wouldn’t you know he’d leave a sinking ship rather than stay around and try to help?^\
Devil of a job /devil’s own job - самое сложное задание - It was the devil’s own job finding a hotel with vacancies.^\
Devil-may-care attitude / devil-maycare manner - легкомысленное отношение - You must get rid of your devil-may-care attitude if you want to succeed.^\
Diamond in the rough - неотшлифованый алмаз; человек, имеющий много достоинств, но грубый внешне - Ann looks like a stupid woman, but she’s a fine person—a real diamond in the rough.^\
Die in one’s boots / die with one’s boots on - умереть в борьбе, в ходу - I won’t let him get me. I’ll die in my boots.^\
Die laughing - умереть смеясь, умереть от смеха - The joke was so funny that I almost died laughing.^\
Die of boredom - умерать от скуки - We sat there and listened politely, even though we almost died of boredom.^\
Different as night and day - абсолютно разные - Although Bobby and Billy are twins, they are as different as night and day.^\
Dig in - приступить к еде; принятся за работу - Dinner’s ready, Tom. Sit down and dig in.^\
Dig one’s heels in - отказаться изменить своё поведение, отношение; быть упёртым - The student dug her heels in and refused to obey the instructions.^\
Dig one’s own grave - копать себе могилу; быть ответсвенным за свою неудачу - The manager tried to get rid of his assistant, but he dug his own grave. He got fired himself for trying.^\
Dig some dirt up on someone - найти компромат на кого-либо - If you don’t stop trying to dig some dirt up on me, I’ll get a lawyer and sue you.^\
Dime a dozen - дешевый, обычный; (10 центов за дюжину) - People who can write good books are not a dime a dozen.^\
Dine with Duke Humphrey - остаться без обеда - Yesterday I was so busy that had to dine with Duke Humphrey.^\
Dirt cheap - очень дешевый - Buy some more of those plums. They’re dirt cheap.^\
Dirty old man - озабоченый сексом - Tell your daughter to stay away from him. He’s a dirty old man and might attack her.^\
Dirty work - грязная работа - The company seems respectable enough, but there’s a lot of dirty work that goes on.^\
Divide and conquer - разделяй и властвуй - Mary thought she could divide and conquer the board of directors, but they had survived such tactics many times, and her efforts failed.^\
Divide something fifty-fifty / split something fifty-fifty - разделить поровну - Tommy and Billy divided the candy fifty-fifty.^\
Do a double take - выражать крайнее удивление - When the boy led a goat into the park, everyone did a double take.^\
Do a flip-flop (on something) / do an about-face - внезапно поменять решение - Without warning, the government did a flip-flop on taxation.^\
Do a job on someone or something - повредить что-либо, кого-либо; сходить по-большому - The robbers really did a job on the bank guard. They beat him when they robbed the bank.^\
Do a land-office business - преуспеть за короткий период времени - The ice cream shop always does а land-office business on a hot day.^\
Do a number on someone or something - повредить что-либо, кого-либо; навредить кому-либо - The teacher did a number on the whole class. That test was terrible.^\
Do a snow job on someone - обманывать - Tom did a snow job on the teacher when he said that he was sick yesterday.^\
Do away with someone or something - избавиться, убить кого-то - The crooks did away with the witness.^\
Do credit to someone / do someone credit - улучшать репутацию - Your new job really does credit to you.^\
Do justice to something - правильно изображать что-либо; съедать или выпивать всё - Bill always does justice to the turkey on Thanksgiving.^\
Do not have a care in the world - быть полностью беззаботным - I really feel good today— as if I didn’t have a care in the world.^\
Do not have a leg to stand on - не иметь поддержки, аргументов - You may think you’re in the right, but you don’t have a leg to stand on.^\
Do not have all one’s marbles - быть умственно неполноценным - John acts as if he doesn’t have all his marbles.^\
Do or die - жизненно важное дело - It was do or die. There was no turning back now.^\
Do someone a good turn - сделать услугу - My neighbor did me a good turn by lending me his car.^\
Do someone or something in - утомить, обмануть, убить, поломать - That tennis game really did me in.^\
Do something fair and square - честно - He always plays the game fair and square.^\
Do something for a living - зарабатывать чем-либо на жизнь - John paints houses for a living.^\
Do something in a heartbeat - делать что-либо мгновенно - If I had the money, I would go back to college in a heartbeat.^\
Do something in person - делать что-либо лично - I know the money should be in his account. I saw him put it there in person.^\
Do something on the fly - делать на бегу, на ходу - We can’t stop the machine to oil it now. You’ll have to do it on the fly.^\
Do something on the sly - делать что-либо тайно - She was supposed to be losing weight, but she was snacking on the sly.^\
Do something up brown - делать что-либо правильно - Come on, Bob. Let’s do it right this time. I know you can do it up brown.^\
Do the dishes - мыть и вытирать посуду - Bill, you cannot go out and play until you’ve done the dishes.^\
Do the honors - обслуживать гостей как хозяин или хозяйка дома - All the guests were seated, and a huge, juicy turkey sat on the table. Jane Thomas turned to her husband and said, “Bob, will do the honors ?” Mr. Jones smiled and began slicing thick slices of meat from the turkey.^\
Dog and pony show - демонстрация чего-либо с целью продажи - Gary was there with his dog and pony show, trying to sell his ideas to whomever would listen to him.^\
Dog in the manger - собака на сене - Jane is a real dog in the manger. She cannot drive, but she will not lend anyone her car.^\
Dog-eat-dog - ситуация, где каждый сам за себя - Universities are not quiet peaceful places. It’s dog-eat-dog to get a promotion.^\
Done to a T / done to a turn - вкусно приготовленный - Yummy! This meat is done to a T.^\
Dose of one’s own medicine - отношение, идентичное тому, как человек ведет себя с другими людьми - Sally never is very friendly. Someone is going to give her a dose of her own medicine someday.^\
Double in brass - делать два дела - The English teacher also doubles in brass as the football coach.^\
Double-cross someone - обмануть кого-либо, не сдержав обещание - Tom is mad at Jane because she double-crossed him on the sale of his car.^\
Doubting Thomas - Фома неверующий; человек, который никому не верит - Mary won’t believe that I have a dog until she sees him. She’s such a doubting Thomas.^\
Down in the dumps - грустный, подавленный - Try to cheer Jane up. She’s down in the dumps for some reason.^\
Down in the mouth - с грустным лицом, не улыбающийся - Since her dog died, Barbara has been down in the mouth.^\
Down on one’s luck - без денег, банкрот - Can you lend me twenty dollars? I’ve been down on my luck lately.^\
Down on someone or something - быть против чего-либо - I’ve been down on red meat lately. It’s better to eat chicken or fish.^\
Down the drain - потерянный навсегда, потраченный зря - I just hate to see all that money go down the drain.^\
Down the hatch - проглотить что-либо (обычно об алкоголе) - John raised his glass of beer and said, “Down the hatch.”^\
Down the tubes - разрушенный, испорченный - His political career went down the tubes after the scandal. He’s lost his job.^\
Down to the wire - в последнюю минуту, до конца - I have to turn this in tomorrow, and I’ll be working down to the wire.^\
Down with some disease - слечь с чем-либо - Sally is down with the flu.^\
Down-and-dirty - нечестный, низкий - The boys played a real down-and-dirty trick on the teacher.^\
Down-and-out - без средств к существованию - John gambled away all his fortune and is now completely down-and-out.^\
Down-at-the-heels - оборваный, изношенный - Tom’s house needs paint. It looks down-at-the-heels.^\
Down-to-earth - прямой, открытый, практичный - It’s good that she’s down-to-earth and will give us a frank response.^\
Downhill all the way - все время легкий - Don’t worry about your algebra course. It’s downhill all the way.^\
Drag one’s feet - волочить ноги, замедлять что-либо - The government is dragging its feet on this bill because it costs too much.^\
Draw a bead on someone or something - нацеливаться на кого-либо, что-либо - Ann wants a new car, and she has drawn a bead on a red convertible.^\
Draw a blank - не получить ответа, забыть о чем-то - I asked him about Tom’s financial problems, and I just drew a blank.^\
Draw a line between something and something else / draw the line between something and something else - разграничить две вещи, разделять понятия - It’s very hard to draw the line between slamming a door and just closing it loudly.^\
Draw blood - оскорбить кого-то, поранить - Sally screamed out a terrible insult at Tom. Judging by the look on his face, she really drew blood.^\
Draw fire - навлечь критику - This film drew fire as soon as it was released.^\
Draw interest - вызывать интерес - This kind of event isn’t likely to draw a lot of interest.^\
Draw lots / draw straws - тянуть жребий - We drew lots to decide who would wash the dishes.^\
Draw someone or something out - вызвать на разговор, тянуть время - John drew out Mr. Smith on the question of tax increases.^\
Drawn and quartered - вести себя очень жестко с кем-либо (четвертовать) - Todd was practically drawn and quartered for losing the Wilson contract.^\
Dream come true - сбывшаяся мечта - Going to Hawaii is like a dream come true.^\
Dressed to kill - очень модно одеться - Wow, look at Sally! She’s really dressed to kill.^\
Dressed to the nines - быть очень хорошо одетым - Tom showed up at the dance dressed to the nines.^\
Dribs and drabs - в маленьких, нерегулярных количествах - All her fortune was spent in dribs and drabs on silly things—like clothes and fine wines.^\
Drink to excess - выпить лишнего - Some people drink to excess only at parties.^\
Drive a hard bargain - усиленно торговаться в свою пользу - I saved $200 by driving a hard bargain when I bought my new car.^\
Drive at something - намекать на что-то - I do not understand what you are telling me. What are you driving at?^\
Drive someone crazy / drive someone mad - сводить с ума - He’s so strange that he actually drove his wife crazy.^\
Drive someone up the wall - свести с ума - All my problems will drive me up the wall someday.^\
Drop a bomb(shell) / explode a bombshell/ drop a brick - сообщить шокирующую новость - They really dropped a bombshell when they announced that the mayor had cancer.^\
Drop dead - внезапно умереть - I understand that Tom Anderson dropped dead at his desk yesterday.^\
Drop in (on someone) / drop in (to say hello) - зайти/ заглянуть - You’re welcome to drop in at any time.^\
Drop in one’s tracks - умереть, остановиться от изнеможения - If I keep working this way, I’ll drop in my tracks.^\
Drop in the ocean / a drop in the bucket - капля в море - But one dollar isn’t enough! That’s just a drop in the ocean.^\
Drop names - упоминать имена известных людей в качестве своих друзей - Mary always tries to impress people by dropping the names of well-known film stars.^\
Drop someone - бросить девушку (парня) - Bob finally dropped Jane. I don’t know what he saw in her.^\
Drop someone a line / drop someone a few lines - написать пару строк - I dropped Aunt Jane a line last Thanksgiving.^\
Drop the bal - совершить ошибку, провалиться - Everything was going fine in the election until my campaign manager dropped the ball.^\
Drop the other shoe - доделать что-то, завершить что-либо - Mr. Franklin has left his wife. Soon he’ll drop the other shoe and divorce her.^\
Drown one’s troubles/ drown one’s sorrows - утопить в алкоголе свои беды и печали - Bill is in the bar, drowning his troubles.^\
Drown someone or something out - заглушать что-то - I can’t hear what you said. The radio drowned you out.^\
Drug on the market - быть в переизбытке на рынке - Right now, small computers are a drug on the market.^\
Drum some business up - стимулировать людей покупать то, что вы продаёте - I need to do something to drum some business up.^\
Drum something into someone(‘s head) - вбить в голову, зазубрить - Yes, I know that. They drummed it into me as a child. Now I’m drumming it into my own children.^\
Dry as dust - сухой, скучный - This book is as dry as dust. I am going to stop reading it^\
Dry run - попытка, репетиция - We had better have a dry run for the official ceremony tomorrow.^\
Dry someone out - отрезвить - We had to call the doctor to help dry Mr. Franklin out.^\
Dry up - замолчать - The young lecturer was so nervous that he forgot what he was going to say and dried up.^\
Duck and cover - увертываться от неприятных вопросов - The candidate’s first reaction to the question was to duck and cover.^\
Dull as dishwater - скучный, неинтересный - I’m not surprised that he can’t find a partner. He’s as dull as dishwater.^\
Dutch courage - необычайная смелость, возникшая под действием алкоголя - It was Dutch courage that made the football fan attack the policeman.^\
Dutch treat - поход в ресторан, где каждый платит сам за себя - “It’s nice of you to ask me out to dinner,” she said, “but could we make it a Dutch treat?”^\
Dutch uncle - человек, который даёт резкие советы, считая себя чьим-либо родственником - He acts more like a Dutch uncle than a husband. He’s forever telling her what to do in public.^\
Dyed-in-the-wool - постоянный, упертый человек - My uncle was a dyed-in-the-wool farmer. He wouldn’t change for anything.^\
Dying to do something - очень хотеть сделать что-либо - After a long hot day like this one, I’m just dying for a cool drink of water.^\
Eager beaver - человек много и охотно работающий, \"трудоголик\" - Sam is not at all an eager beaver; he hates hard work.^\
Eagle eye - зоркий глаз, \"орлиный глаз\" - Alan kept an eagle eye upon all Carry’s activities.^\
Early bird - человек, встающий рано, \"ранняя пташка\", \"жаворонок\" - \"I hate getting up early; I am not an early bird, I must confess.\"^\
Earn one's keep - оправдывать своё содержание работой - I stayed with a host family and helped them about the house in order to earn my keep.^\
Easy as (apple) pie - очень лёгкий - Making a simple dress out of cotton cloth is easy as pie.^\
Easy as duck soup - очень лёгкий - Getting Bob to eat fried chicken is as easy as duck soup.^\
Easy does it. - вести себя с осторожностью - Be careful with that glass vase. Easy does it!^\
Eat away at someone or something - съедать частями; очень волноваться - John’s disease was eating away at him.^\
Eat high on the hog - кушать дорогую еду - John would have more money to spend on clothing if he didn’t eat so high on the hog.^\
Eat humble pie - принимать оскорбления и унижения - John, stand up for your rights. You don’t have to eat humble pie all the time.^\
Eat like a bird - кушать как птичка (очень мало) - Jane is very slim because she eats like a bird.^\
Eat like a horse - много кушать - John works like a horse and eats like a horse, so he never gets fat.^\
Eat one’s heart out - быть очень грустным; завидовать кому-то - Sally ate her heart out when she had to sell her house.^\
Eat one’s words - забрать свои слова обратно - John was wrong about the election and had to eat his words.^\
Eat out of (someone's) hand - безоговорочно подчиняться кому-либо, \"плясать под чью-либо дудку\" - Jack is a very proud man. I don’t think he is capable of eating out of anybody’s hand.^\
Eat something up - наслаждаться, увлекаться чем-либо - The children ate up Grandfather’s stories. They listened to him for hours.^\
Ebb and flow - взлёт и падение - The ebb and flow in the profession of an artist is quite a common thing.^\
Edge someone out - вытеснить кого-то с работы - Tom edged out Bob as the new cook at the restaurant.^\
Egg someone on - подначивать кого-либо сделать что-то (обычно неразумное) - John wouldn’t have done the dangerous experiment if his brother hadn’t egged him on.^\
Either feast or famine - то переизбыток, то недостача - This month is very dry, and last month it rained almost every day. Our weather is either feast or famine.^\
Elbow someone out (of something) - вытолкать кого-то из какого-то учреждения - The old head of the company was elbowed out of office by a young vice president.^\
Eleventh-hour decision - решение, принятое в последний момент - The president’s eleventh-hour decision was made in a great hurry, but it turned out to be correct.^\
Engage in small talk - говорить о чем-то не очень важном - All the people at the party were engaging in small talk.^\
Enjoy your meal. - Приятного аппетита! - Do you have the medium steak? Enjoy your meal.^\
Enter one’s mind - прийти в голову - A very interesting idea just entered my mind. What if I ran for Congress?^\
Escape someone’s notice - остаться не замеченным - I’m sorry. Your letter escaped my notice.^\
Even steven - быть равным - Bill hit Tom; then Tom hit Bill. Now they are even steven.^\
Every nook and cranny - обыскать каждый закуток - We looked for the tickets in every nook and cranny. They were lost. There was no doubt.^\
Every Tom, Dick, and Harry - обычные люди - The golf club is very exclusive. They don’t let any Tom, Dick, and Harry join.^\
Every which way - во всех направлениях - The wind scattered the leaves every which way.^\
Everything but the kitchen sink - всё, о чем можно подумать - John orders everything but the kitchen sink when he goes out to dinner, especially if someone else is paying for it.^\
Everything from soup to nuts / everything from A to Z - всё - In college I studied everything from soup to nuts.^\
Everything’s coming up roses. - всё прекрасно - Life is wonderful. Everything is coming up roses.^\
Exciting as watching (the) paint dry - очень скучный - This book is about as exciting as watching paint dry.^\
Extend one’s sympathy (to someone) - выражать соболезнование - Please permit me to extend my sympathy to you and your children. I’m very sorry to hear of the death of your husband.^\
Extenuating circumstances - смягчающие обстоятельства - Mary was permitted to arrive late because of extenuating circumstances.^\
Eye of the storm - корень проблемы - The manager’s office was known as the eye of the storm since all the major problems ended up there.^\
Eyeball-to-eyeball - лицом к лицу - Telephone conversations are a waste of time. We need to talk eyeball-to-eyeball.^\
Face the music - понести заслуженное наказание - Mary broke a dining-room window and had to face the music when her father got home.^\
Facts of life - информация о размножении (обычно людей); правда жизни - My parents told me the facts of life when I was nine years old.^\
Fair game - легкая мишень (обычно так говорят о людях, в чью личную жизнь вторгаются журналисты) - I don’t like seeing articles exposing people’s private lives, but politicians are fair game.^\
Fair-haired boy - любимчик - The teacher’s fair-haired boy always does well on tests.^\
Fair-weather friend - друг, который остаётся с тобой только в радости и исчезает, когда у тебя проблемы - Bill wouldn’t help me with my homework. He’s just a fair-weather friend.^\
Fall afoul of someone or something / run afoul of someone or something - попасть в беду - Dan fell afoul of the law at an early age.^\
Fall all over someone - упадать за кем-то, уделять слишком много внимания - My aunt falls all over me whenever she comes to visit.^\
Fall apart at the seams - распадаться на куски, трещать по швам - This old car is about ready to fall apart at the seams.^\
Fall asleep - уснуть - The baby cried and cried and finally fell asleep.^\
Fall between two stools - не соответствовать требованиям ни одной из сторон - He tries to be both teacher and friend, but falls between two stools.^\
Fall by the wayside / drop by the wayside - остановиться на полпути - Many people start out to train for a career in medicine, but some of them drop by the wayside.^\
Fall down on the job - не справляться с работой - The team kept losing because the coach was falling down on the job.^\
Fall flat (on one’s face) / fall flat (on its face) - быть полной неудачей - My jokes fall flat most of the time.^\
Fall from grace - перестать быть любимчиком, пасть в немилость - Mary was the favorite grandchild until she fell from grace by running away from home.^\
Fall head over heels in love (with someone) - влюбиться до беспамятства - Roger fell head over heels in love with Maggie, and they were married within the month.^\
Fall ill - заболеть - We both fell ill after eating the baked fish.^\
Fall in - построиться в шеренгу - The Boy Scouts were told to fall in behind the scoutmaster.^\
First aid - неотложная помощь - After the accident I had to give the first aid to the injured people^\
Fit (someone) to a T - прекрасно подходить кому-либо - My friend’s new apartment fits her to a T.^\
Fit as a fiddle - здоровый, в хорошем состоянии - Tom used to be fit as a fiddle. Look at him now!^\
Fit the axe into the helve - преодолеть трудность, достичь цели - It was not so easy to fit the axe into the helve but I managed to.^\
Flat as a pancake - плоский как блин - Bobby squashed the ant f lat as a pancake.^\
For all intents and purposes - фактически, на самом деле - For all intents and purposes the construction of the dwelling house was practically finished.^\
Free as a bird - беззаботный, абсолютно свободный - Jane is always happy and free as a bird.^\
Fresh as a daisy - свежий как роза - Sally was fresh as a daisy and cheerful as could be.^\
From afar - издалека - He started from afar, because it was difficult for him to confess in his feelings.^\
Full ahead! - Полный вперёд^\
Full blast - на всю громкость - The car radio was on full blast. We couldn’t hear what the driver was saying.^\
Full-fledged - полноценный, вполне развитый - Having worked for a few years, Tim Noaland became a full-fledged engineer.^\
Funny as a barrel of monkeys - весёлый, смешной - The entire evening was funny as a barrel of monkeys.^\
Funny as a crutch - несмешной - The welldressed lady slipped and fell in the gutter, which was funny as a crutch.^\
Gaudy as a butterfly - разноцветный - Michael’s scarf is gaudy as a butterf ly.^\
Get a word in edgewise - встрять в разговор - My Mom and Dad were talking, and I wanted to get a word in edgewise, but then I changed my mind.^\
Get around to doing something - собраться делать что-то - Let's get around to cleaning the house.^\
Get off the hook - освободиться от обязательства, \"сорваться с крючка\" - Jerry got off the hook and didn't have to pay alimony to his wife.^\
Give (someone) an earful - поругать кого-либо - My mother gave me an earful because I had come home in the middle of the night.^\
Give credence to (someone or something) - поверить кому-либо чему-либо - They didn't want to give credence to the man's statement so they ignored it.^\
Give somebody the bag to hold - оставить в беде - They gave me the bag to hold and ran away.^\
Go aloft - умереть - My grandfather went aloft but I still miss him^\
Go back from one's word - отказываться от обещания - Don't trust him, he always goes back from his word.^\
Go through the roof - взлететь (о ценах) - The price of old houses suddenly went through the roof.^\
Good as gold - искренний, настоящий - Yes, this diamond is genuine—good as gold.^\
Grasp at straws - пытаться что-либо делать без надежды на успех; \"хвататься за соломенку\" - I was grasping at straws, trying to pay back my bank loan.^\
Grounds for (something) - основание для чего-либо - The fact that Bill Kraft often came to work late was grounds for his dismissal from office.^\
Gruff as a bear - хмурый, молчаливый - I’m always as gruff as a bear before I’ve had my first cup of coffee.^\
Hang out (somewhere/with someone) - слоняться, болтаться где-либо с кем-либо - Sandra has been hanging out with her friends all summer.^\
Hang up one's axe - отойти от дел - Mister Lewes hung up his axe long ago, but people still refered to him.^\
Happy as a lark - весёлый - The children danced and sang, happy as larks.^\
Hard as a rock - твёрдый как камень - I can’t drive a nail into this wood. It’s hard as stone.^\
Hard as nails - жесткий - Ann was unpleasant and hard as nails.^\
Have (something) up one's sleeve - держать что-либо в тайне до подходящего времени; иметь что-либо про запас - Scott was not afraid of being fired as he had some slanderous information up his sleeve about the firm.^\
Have a crush on (someone) - сильно увлечься кем-либо - Fred had a crush on Maria.^\
Have an affair - иметь любовный роман - He had many affairs before his marriage with Jill.^\
Have an axe to grind - преследовать личные цели; затаить злость - She has an axe to grind, that's why she is so persistent.^\
Have it - найти ответ, понять - Sam finally had it. They had no desire to participate in the elections.^\
Have mixed feelings about (someone or something) - иметь смешанные чувства по поводу кого-либо чего-либо - I have been offered a new job, but I have mixed feelings about accepting it.^\
Have one`s nose in (something) - проявлять непрошенный интерес любопытство к чему-либо - Patricia is a nosy Parker; she likes to have her nose in other people’s private affairs.^\
Have rat's in the attic - человек с мухами в голове, странный человек - Jane was said to have rat's in the attic, that's why she had no friends.^\
Have the ball at one's feet - бытьхазяином положения - He had the ball at his feet and could do whatever he wanted^\
Hear (someone) out - выслушать кого-либо - I know I am guilty, but will you, please, hear me out?^\
High as a kite - 1.высокий 2. пьяный - The tree grew as high as a kite. Bill drank beer until he got as high as a kite^\
Hit the dirt - лечь на землю и укрыться от огня - The hold-up men ordered the hostages to hit the dirt.^\
Hit the road - смотаться, переезжать с места на место - Hit the road, Jack !^\
Hoarse as a crow - хриплый - After shouting at the team all afternoon, the coach was as hoarse as a crow.^\
How about/ What about...? - как насчет...? - What about going to France for our holidays?^\
Hungry as a hunter - голодный как волк - We’d better have a big meal ready by the time Tommy gets home; he’s always hungry as a hunter after soccer practice.^\
Idiot box - телевизор - My brother sits glued to the idiot box all day long.^\
If looks could kill - убийственный злобный взгляд; \"если бы взглядом можно было убить\" - If looks could kill, then the look he gave me would have killed me at once.^\
If the shoe fits, wear it - если вы принимаете замечание на свой счёт, пусть будет так; \"на воре шапка горит\" - Ann was mortally offended by my harmless remark. I looked at her and said that if the shoe fits, wear it.^\
Ill at ease - чувствовать себя неловко, нервничать - I saw that Jimmy felt ill at ease and decided not to tell him about his failure.^\
Impudent baggage - нахалка, мошенница - Henry's bride is an impudent baggage^\
In abject poverty - в крайней нужде - They lived in abject poverty.^\
In practice - подготовленный - It must have been six years since I took a girl out, and I wasn't in practice for the dating game.^\
In the buff/raw - без одежды, нагишом - Eva was taking a shower and was in the raw when the telephone rang.^\
In the chips - (быть) состоятельным - Ricardo has always wanted to be in the chips.^\
In the mainstream - главное течение, основное направление, современные тенденции, (быть) в русле - Bob is too old-fashioned to be in the mainstream of modern living.^\
In the nick of time - в самый последний момент - My father nearly missed his train; he was able to get into his carriage in the nick of time.^\
In the prime of life - во цвете лет, в расцвете сил - While traveling in Africa, Herbert was infected with a strange disease and died in the prime of life.^\
It is above me! - Это выше моего понимания!^\
Jack up (something) - поднять цены; поднять что-либо при помощи домкрата - It is difficult to rent a good house for a decent price; the owners have jacked up their prices.^\
Jack-of-all-trades - мастер на все руки - Tom is a jack-of-all-trades and master of none.^\
Jam-packed - переполненный - I usually take a bus to go to work, but it is always jam-packed during rush hours.^\
Jekyll and Hyde - кто-либо, сочетающий в себе хорошее и плохое - My ex-husband is like Jekyll and Hyde. One minute he is all smiles but the next minute he is irritated.^\
Jockey for position - не стесняться в средствах для достижения цели - \"I don’t think it’s the right time to jockey for position when the company is in a hole.\"^\
John Doe - воображаемый истец в судебном процессе - They use the name \"John Doe\" as the name of a person who is applying for something.^\
Jump out of one`s skin - вздрогнуть, подскочить (от испуга, неожиданности) - When Nancy heard moans and groans coming from the basement, she jumped out of her skin.^\
Jump( swallow) at the bait - попасться на удочку - Poll jumped at the bait of her flattery.^\
Kangaroo court - неправедный суд, незаконное разбирательство - \"I refuse to be convicted by a kangaroo court!\"^\
Keep a tight/close rein on (someone or something) - держать в узде, в ежовых рукавицах, строго контролировать - The Manager of Department kept a tight rein on the staff.^\
Keep at arm's length - держать на растоянии - Sarah is a real gossip, keep her at arm's length^\
Keep body and soul together - жить впроголодь, едва сводить концы с концами - I earned very little money that year and could hardly keep body and soul together.^\
Keep up appearances - соблюдать приличия - She tried to keep up appearances but it was very difficult under the circumstances^\
Kettle of fish - неудовлетворительная ситуация, неразбериха - \"This is a fine kettle of fish. What will we do without the water in our house?\"^\
Kickback - незаконно выплаченные деньги, взятка - The company had to give Deputy Mayor a kickback in order to win the market.^\
Know-it-all - всезнайка - Jacob is a know-it-all that’s why I don’t think much of him.^\
Lace into (someone) - резко критиковать, набрасываться на кого-либо - My father laced into me when I didn’t do my chore.^\
Lady killer - красавчик, любимец женщин - Jeremy is a regular lady killer; he has broken the hearts of a lot of women.^\
Lady’s man - дамский угодник, ловелас - Bill was a lady’s man, and like all such men he was vain and conscious of his charm for the opposite sex.^\
Lame duck - неудачник, \"несчастненький\" - The prospect of his daughter’s life being spent among lame ducks worried him.^\
Land of Nod - сонное царство - I came home late that night and found my parents in the land of Nod.^\
Last but not least - последний по счёту, но не последний по значению - He was last but not least in his attempt to improve the situation.^\
Last-ditch effort - последнее усилие - Adam made a last-ditch effort to persuade his friend not to immigrate to Canada.^\
Laugh up one's sleeve - тихо посмеяться (сам с собой), \"смеяться в кулак\" - Maria laughed up her sleeve when she learned that her friend had bought a ridiculous dress at the sale.^\
Law unto oneself - сам себе закон - \"Don’t think you are a law unto yourself; your behavior is outrageous.\"^\
Left-handed compliment - неуклюжий, двусмысленный комплимент - Julia didn’t like her new jacket and hated her friend to give her a left-handed compliment.^\
Let alone - дать покой - Let me alone,I don't want to talk with you^\
Light as a feather - легкий как пух - Of course I can lift the box. It’s light as a feather.^\
Little bird told me - мне стало известно по секрету, \"сорока на хвосте принесла\" - A little bird told me that my Mom would give me a nice present for my birthday.^\
Loudmouth - болтун, трепло - Ron is a loudmouth; he is also noisy and boastful.^\
Luck out - внезапно повести - I lucked out with the railway tickets and was able to get good seats in the train.^\
Lull (someone) into a false sense of security - усыпить чью-либо бдительность - The inhabitants of Troy were lulled into a false sense of security by being given a wooden horse as a gift.^\
Lull before the storm - затишье перед бурей - It was the lull before the storm when my boss walked into our office to speak about our new work schedule.^\
Mad as a hatter - спятивший, не в своём уме - Keep an eye on the man; he is mad as a hatter.^\
Make a comeback - возвратиться (к прежней успешной карьере, власти, популярности) - After the injury the figure skater has been training very hard in order to make a comeback.^\
Make a difference - существенно менять дело, быть важным - It doesn’t make any difference to me if they will invite me to stay with them or not.^\
Make a fast/quick buck - быстро и легко заработать деньги - Alan Grove made a fast buck during the war by supplying ammunition for the army.^\
Make a fool out of (someone) - выставить кого-либо дураком - \"Don’t you ever try to make a fool out of me! I am not going to believe your fancy stories.\"^\
Make a go of (something) - добиваться успеха, преуспевать - Fanny and Peter got engaged, but then they talked things over and decided they couldn’t make a go of it.^\
Make an apology - извинится - John made an apology for being late^\
Make an ass of oneself - поставить себя в глупое положение - The speaker made an ass of himself making one mistake after another.^\
Make arrangements (with somebody) - договариваться с кем-либо - All arrangements were made and we could easily start our journey.^\
Man-about-town - светский человек - Alec is a man-about-town and a good mixer; he likes to mess around.^\
Match for (someone) - быть под стать кому-либо - The Russian football team wasn't a match for the French one.^\
Matter of life and death - вопрос жизни и смерти, жизненно важный вопрос - \"Do be serious for just five minutes! After all, it is a matter of life and death.\"^\
Meant to be - предназначать, быть начертанным судьбой - It was meant to be that Jim and Mary fell in love at first sight.^\
Meat-and-potatoes - безыскусный, простой - To my mind the best approach to life is meat-and-potatoes one.^\
Meet the requirements (for something) - соответствовать требованиям для чего-либо - The young teacher didn’t meet the requirements for a substitute teacher.^\
Mend fences with (someone) - стараться подружиться, установить дружеские отношения - After some disagreement Peter tried to mend fences with everybody in the group.^\
Mess around/about - тусоваться, бездельничать - \"I can’t understand Dave; the guy is always messing around doing nothing.\"^\
Mess up - испортить, доставлять неприятности - Jenny messed up her chance to get a good job by refusing to go to an interview.^\
Milestone in someone's life - очень важное событие в чьей-либо жизни - The birth of her baby was a milestone in the young woman's life.^\
Mince (one's) words - говорить нечётко, \"жевать слова\" - The speaker was mincing his words and it was difficult to understand him.^\
Mind your own affairs! - Не лезьте не в своё дело!^\
Miss the point - не понять важность чего-либо - This is the most important part of the story, but I think most of the students have missed the point.^\
Mistake (someone) for (someone) else - ошибочно принять кого-либо за кого-либо - The man started to talk to me, but then he stopped. Evidently he had mistaken me for somebody else.^\
Much ado about nothing - много шума из ничего^\
Must have - насущная потребность - New computer software is a must have for computer users.^\
Nail down (someone or something) - требовать от кого-либо выполнения чего-либо - We were nailed down to post all the cards before 5 o'clock.^\
Naked eye - невооружённый глаз - The picture was so big; and even a very short-sighted person can see it with a naked eye.^\
Name (someone) after (someone or something) - назвать кого-либо в честь кого-либо или чего-либо - Many children are named after famous people.^\
Neat as a pin - аккуратный, с иголочки - Joanne certainly is well-organized. Her desk is neat as a pin.^\
Neck of the woods - район, местность где живёшь - If Jim talks about his neck of the woods, he means the area where he lives.^\
Need (something) like (one needs) a hole in the head - совершенно ненужная (вещь), \"как собаке пятая нога\" - He needs a new fishing tackle like he needs a hole in the head.^\
Neither fish nor fowl - не рыба, ни мясо (о безвольном человеке); ни то ни сё - Mike is neither fish nor fowl, and he doesn't really fit into any of the student groups.^\
Never mind - не важно, не беспокойся - Never mind, it is not so urgent.^\
New blood - свежая кровь (люди с новыми идеями) - The company needed new blood: new ideas and people to carry out these ideas.^\
Nickel and dime (someone) - постоянно просить у кого-либо денег или тратить небольшие суммы - My cousin Ben is constantly asking for small sums of money; I am afraid he will nickel and dime me to death.^\
Night owl - сова (человек, который поздно ложиться спать) - I am a night owl and my husband is an early bird.^\
Nine day's wonder - кратковременная сенсация, предмет недолгих толков - The pop singer was a nine day's wonder and it was not surprising that he was soon forgotten.^\
Nine-to-five-job - нормированный рабочий день (с 9 до 5) - The majority of people prefer to work the regular hours of a nine-to-five- job.^\
No bed of roses - трудная или плохая ситуация - It is no bed of roses to be unemployed and not to be able to support the family.^\
No kidding - без шуток - \"No kidding, is Simon really going to buy a Jaguar?\"^\
No-show - не явившийся (человек, который делает заказ, а затем не является за ним) - If was probably because of the storm that there were many no-shows for a boat trip.^\
Not a moment to spare - ни минуты свободной - I have been very busy lately with not a moment to spare.^\
Not lift a finger/hand (to help someone) - пальцем не пошевелить (чтобы помочь кому-либо) - He saw that she was suffering, but he did not lift a finger to help her.^\
Not move a muscle - не двигаться, не шевелиться - The doctor told the wounded soldier not to move a muscle while he was working on his wound.^\
Not see past/farther than the end of one's nose - быть не дальновидным, не видеть дальше своего носа - Arthur could not see farther than the end of his nose and never planned anything for the future.^\
Not sleep a wink - глаз не сомкнуть - My next door neighbors were having a party all night and I could not sleep a wink.^\
Not to touch alcohol - быть трезвенником - My brother doesn't touch alcohol, he is a sportsman^\
Not worth a cent - не стоить ни гроша - The house is falling to pieces and is not worth a cent.^\
Not worth mentioning - не стоит упоминания - I’d rather John didn’t speak about this problem; I am sure it is not worth mentioning.^\
Now and again - иногда - The sunrays came over her beautiful face now and again and made it even more delicate.^\
Nurse a grudge - иметь зуб на кого-либо - Margaret hated her ex-husband was nursing a grudge toward him for years.^\
Nuts about (someone or something) - сходить с ума по кому-либо чему-либо - Bob has been nuts about boats and ships ever since he was a boy of ten.^\
Nuts and bolts (of something) - основные сведения о чём-либо - The nuts and bolts of the research were carefully discussed by the student and his mentor.^\
Odd man out - третий лишний - The two of them were chatting merrily and I felt as if I were the odd man out in their company.^\
Odds and ends - остатки, обрезки, разные мелочи - The tailor made a suit for the boy out of the odds and ends of the cloth.^\
Old as the hills - очень старый - I decided not to buy that house because it looked as old as the hills.^\
On the anvil - в работе, в процессе обсуждения - The case being on the anvil, we had no right to comment it^\
Once and for all - раз и навсегда - Forget him once and for all^\
One's lucky stars - чья-либо счастливая звезда - I don’t have my lucky stars because nothing brings me luck or success in life.^\
One's name is mud - плохая, \"подмоченная\" репутация - Henry’s name is mud now because he got involved in a car fraud.^\
One-armed bandit - игровой автомат, \"однорукий бандит\" - William is always short of money because he spends a lot of time with a one-armed bandit.^\
One-night stand - одноразовое мероприятие - The amateur drama performers played a one-night stand in the park.^\
One-track mind - думать только об одном, \"заклиниться\" на одном - Joanna is a workaholic and has a one-track mind. All she thinks about is her work.^\
Pale as death - бледный как смерть - What’s the matter? You’re pale as death!^\
Patient as Job - терпеливый - If you want to teach young children, you must be as patient as Job.^\
Phony as a three-dollar bill - фальшивый - The whole deal stinks. It’s as phony as a three-dollar bill.^\
Pillar of strength/support - сильный, могущественный человек; опора, поддержка. - They considered their boss a pillar of strength in the company^\
Plain as a pikestaff - очевидный - FRED: I have a suspicion that Marcia is upset with me. ALAN: A suspicion? Come on, Fred, that’s been plain as a pikestaff for quite some time!^\
Plain as the nose on one’s face - очевидный - What do you mean you don’t understand? It’s as plain as the nose on your face.^\
Poor as a church mouse - очень бедный - The Browns are poor as church mice.^\
Proud as a peacock - гордый как павлин - John is so arrogant. He’s as proud as a peacock.^\
Put on airs - напускать важность, вести себя надменно - Nobody liked her because she always put on airs^\
Quake in one's boots - трястись от страха - While walking along a dark alley, Tony was quaking in his boots.^\
Queer as a three-dollar bill - очень странный (как банкнота в 3 доллара) - What John showed me is the strangest thing I have ever seen; it is as queer as a three-dollar bill.^\
Quick and dirty - сделанный на скорую руку, тяп-ляп - The methods that the firm has chosen to cut expenses are quick and dirty.^\
Quick as a flash - с быстротой молнии, в мгновение ока - The lightening struck a tree in the garden; it happened quick as a flash.^\
Quick as greased lightning - очень быстро - Jane can really run. She’s as quick as greased lightning.^\
Quick on the draw - быстро реагирующий, прыткий - The man was quick on the draw; he drew a gun and began shooting.^\
Quiet as a mouse - тихий как мышь - \"Stay where you are till I come back and be as quiet as a mouse.\"^\
Race against time - стремление выиграть время - It was a race against time as I was trying to meet the grant requirements.^\
Read the handwriting on the wall - предвидеть что-либо (подмечая детали и намёки) - I could easily read the handwriting on the wall, and I knew beforehand what was going to happen to our firm.^\
Read the riot act (to someone) - строго предупредить кого-либо - The mother read the riot act to the kids; she told them that if they didn’t stop making noise, they’d get it hot.^\
Real McCoy - подлинная вещь - Jim was sure that the picture he had bought at the auction was the real McCoy.^\
Rear its ugly head - (что-либо неприятное) вновь становиться очевидным - The problem of cockroaches has reared its ugly head in my apartment again.^\
Receive/welcome (someone) with open arms - встретить кого-либо с распростертыми объятиями - When my friends came to visit us, we welcomed them with open arms.^\
Regular as clockwork - регулярно - She comes into this store every day, as regular as clockwork.^\
Rest in peace - покоиться с миром - They prayed that their uncle would rest in peace after he recently passed away.^\
Return the favor - ответить добром на добро - I decided to return the favor to Miss Abramson who had been taking care of my cat when I had been away on holiday.^\
Right as rain - правильный, настоящий - Your answer is as right as rain.^\
Rude awakening - горькое разочарование - It was a rude awakening for her to know that her husband betrayed their love.^\
Run rain or shine - работать при любой погоде - We will run it rain or shine.^\
Save one's bacon - спасать свою шкуру - Jason did all to save his bacon^\
Say amen to sth - соглашаться с чем-либо - My mother said amen to my plans^\
Second to none - непревзойденный - He is second to none as a teacher.^\
Set one's bag for - заигрывать - Sally set her bag for Tom, but all in vain.^\
Sharp as a razor - острый как бритва - The old man’s senile, but his wife is as sharp as a razor.^\
Sharp as a tack - умный, смышлённый - Sue can figure things out from even the slightest hint. She’s as sharp as a tack.^\
Sick as a dog - больной - Sally was as sick as a dog and couldn’t go to the party.^\
Silent as the dead and (as) silent as the grave - тихий, молчаливый, берегущий тайну - Jessica is as silent as the grave on the subject of her first marriage^\
Silly as a goose - глупый как гусь - Edith is as silly as a goose. She thinks that reading aloud to her houseplants will help them grow^\
Slick as a whistle - быстро и четко - Tom took a broom and a mop and cleaned the place up as slick as a whistle.^\
Slippery as an eel - скользкий как уж - Tom can’t be trusted. He’s as slippery as an eel.^\
Slow as molasses in January - медленный - Can’t you get dressed any faster? I declare, you’re as slow as molasses in January.^\
Sly as a fox - хитрый как лис - My nephew is as sly as a fox.^\
Smooth as silk - гладкий как шелк - Your skin is as smooth as silk.^\
Snug as a bug in a rug - уютный - What a lovely little house! I know I’ll be snug as a bug in a rug.^\
Sober as a judge - трезвый, формальный - You certainly look gloomy, Bill. You’re sober as a judge^\
Soft as velvet - нежный как бархат - The horse’s nose felt as soft as velvet.^\
Solid as a rock - твёрдый как камень, надёжный - This company builds typewriters that are as solid as a rock.^\
Sound as a dollar - надёжный - The garage is still sound as a dollar. Why tear it down?^\
Sour as vinegar - кислый как лимон - The old man greeted us illnaturedly, his face as sour as vinegar.^\
Steady as a rock - твёрдый, неподвижный - His hand was steady as a rock as he pulled the trigger of the revolver.^\
Stiff as a poker - тугой, негнущийся - John is not a very good dancer; he’s stiff as a poker.^\
Straight as an arrow - прямой, честный - Tom is straight as an arrow. I’d trust him with anything.^\
Strong as a horse - сильный как слон - The athlete was strong as a horse. He could lift his own weight with just one hand.^\
Strong as a lion - сильный как лев - See if you can get Melissa to help us move our furniture. She’s as strong as a lion.^\
Stubborn as a mule - упёртый как осёл - My husband is as stubborn as a mule^\
Sure as death - точно, непременно - As political tension increased, it became more and more apparent that war was coming, as sure as death.^\
Sweet as honey and (as) sweet as sugar - сладкий как мёд - These little cakes are as sweet as honey^\
Take the airs - прогулятся - Let's take the airs, I need some minutes to relax.^\
Take the wind out of one's sails - ставить в безвыходное положение - Her refusal took the wind out of his sails.^\
Talk billingsgate - ругаться как уличная торговка - Please, calm down. You talk billingsgate.^\
That's the way the cookie crumbles - Вот такие пироги с котятами (букв: \"Вот так вот печенька и крошится\").^\
The ace of aces - лучший из лучших - John is the ace of aces in his trade, you can trust him.^\
The name of the game - главное, основное дело - The name of the game is selling printed matter and not dealing with other things.^\
Thick as pea soup - очень густой - This fog is as thick as pea soup.^\
Thick as thieves - близкие люди, закадычные друзья - Those two families are thick as thieves.^\
Tight as a drum - тугой, натянутый - Julia stretched the upholstery fabric over the seat of the chair until it was as tight as a drum.^\
Tight as a drum - жадный - He won’t contribute a cent. He’s as tight as a drum.^\
Tight as a tick - накормленный до отвала - Little Billy ate and ate until he was as tight as a tick.^\
Tight as Dick’s hatband - тугой, натянутый - I’ve got to lose some weight. My belt is as tight as Dick’s hatband.^\
To abjure a claim - отказываться от претензии, иска - After long negotiations the client abjured his claim.^\
To be ablaze with anger - полыхать от гнева - Ablazed with anger,he left the room.^\
To be able to do sth - уметь, иметь возможность - Will you be able to come?^\
To be hoisted by one's own petard - За что боролись, на то и напоролись (букв: \"Подорваться на собственной петарде\")^\
To be taken aback - быть удивлённым, быть ошарашенным - He was taken aback by the cost of the repaires.^\
To be tired to one's wife's apron-string - быть под каблуком у жены - John was tired to his wife's apron-string and couldn't make any decision without her.^\
To the backbone - до мозга костей, полностью - He is English to the backbone^\
To the best of one's abilities - в меру сил, способностей - He worked to the best of his abilities.^\
Tough as an old boot - твёрдый - This meat is tough as an old boot^\
Tread upon air - триумфовать - He won the competition and could tread upon air^\
True as steel - надёжный - Through all my troubles, my husband has been as true as steel^\
Turn to dust and ashes - розлететься в пух и прах - After the exams all my hopes to enter the university turned to dust and ashes.^\
Ugly as a toad - уродливый как жаба - The shopkeeper was ugly as a toad, but he was kind and generous, and everyone loved him.^\
Ugly duckling - гадкий утёнок - Nancy was the ugly duckling in her family, until she grew up.^\
Unaccustomed to (someone or something) - быть непривычным для кого-либо чего-либо - On the hike Bob soon got tired, because he was unaccustomed to walking.^\
Under (close) scrutiny - под пристальным вниманием - The ex-criminal was under close scrutiny of the police.^\
Under a cloud - быть в подавленном состоянии - Jenny has been under a cloud of depression since her parrot escaped.^\
Vanish into thin air - исчезнуть, раствориться в воздухе - Joe’s new camera just vanished into thin air and was never seen again.^\
Variety is the spice of life - разнообразие – острота жизни - It is believed that variety is the spice of life and I think it is true.^\
Vent one's spleen - избавиться от раздражения или злобы - I am very angry at the manager’s suggestion to transfer me to another department and I haven’t been able to vent my spleen so far.^\
Verge on (something) - граничить с чем-либо - The flood may verge on becoming a real disaster if the water rises a few more meters.^\
Vicious circle - заколдованный круг, порочный круг - Jane takes a lot of medicine to cure her asthma; I am afraid she might develop another illness from the medicine and will thus be caught in a vicious circle.^\
Vim and vigor - настойчивость, сила и энергия - My Grandfather is over seventy, but he is still full of vim and vigor.^\
Vote down - отклонить что-либо при голосовании - The question of opening a casino was raised and was immediately voted down.^\
Wait on (someone) hand and foot - делать всё возможное для кого-либо, служить верой и правдой - Moira is a spoiled child because her parents wait on her hand and foot.^\
Wait with bated breath - ждать с нетерпением; ждать, затаив дыхание - Jack waited with bated breath for the results of his medical tests.^\
Wait-and-see attitude - нерешительная, выжидательная позиция - If you are uncertain about something, it’s always wise to take a wait-and-see attitude.^\
Warm as toast - тёплый и уютный - We were as warm as toast by the side of the fire.^\
Weak as a kitten - слабый как котёнок - John is as weak as a kitten because he doesn’t eat well.^\
White as a sheet - бледный как смерть - Mary went as white as a sheet when she heard the news.^\
Wise as an owl - мудрый как сова - Grandfather is as wise as an owl.^\
Wise as Solomon - мудрый - This is a difficult problem. You’d need to be as wise as Solomon to be able to solve it^\
Word to the wise - умный понимает с полуслова - The boss had once spoken to Jerry about being late all the time, and he supposed that a word to the wise was enough.^\
Work out - тренироваться - Hillary wants to lose weight, so she works out in the gym two hours every day.^\
Work out (for the best) - успешно закончиться, принести результаты - If this commuter bus service works out, it will be used in other parts of the city.^\
Work over - угрожать или избить (кого-либо) - Last Saturday right after midnight, the hoodlums worked over Timothy in the park.^\
Work up - возбуждать, доводить до (какого-либо эмоционального состояния) - Samuel couldn’t work up any interest in the book he was trying to read.^\
Work wonders (with someone or something) - творить чудеса, быть благоприятным для кого-либо чего-либо - “A good night’s sleep will work wonders with you.”^\
Worked up - взволнованный, обеспокоенный - Something must have happened; Sally sounded all worked up over the phone.^\
World is one's oyster - всё возможно для кого-либо, всё достижимо - When Mark won the scholarship, he felt as though the world was his oyster.^\
Worm one's way out of something - (с трудом) находить выход из затруднительного положения - I hate to wash up, so I decided to worm my way out of this responsibility.^\
Worse for wear - поношенный, истрёпанный - I had to buy a new pair of jeans because my old ones looked the worse for wear.^\
Worth one's while - стоить затраченного времени или труда - I’d rather you didn’t repair your car by yourself; it is not worth your while.^\
Worthy of the name - достойный имени - The food in the restaurant is fantastic and the restaurant itself is more than worthy of the great chef's name.^\
Wrap around one’s finger - полностью контролировать кого-либо, быть под каблуком у кого-либо - Sue is very popular with boys, and she can easily wrap any of them around her finger.^\
X marks the spot - обозначение точного места - They looked at the map and saw that X marked the spot where the plane had crashed.^\
Xfiles - секретные материалы - John had no access to Xfiles.^\
Yakety-yak - праздная болтовня - Alan sat behind two young girls on the bus and he got tired of their silly yakety-yak.^\
Year after year - год за годом, много лет - Felicity and David went out year after year until they finally got married.^\
Yellow journalism - жёлтая пресса - Yellow journalism is hardly ever really and truly informative.^\
Yellow streak - трусость (как черта характера) - Jack has a yellow streak in his character; he is afraid of his enemies and never defends his friends.^\
Yellow-bellied - чрезвычайно робкий или трусливый - Derek Prichard is a yellow-bellied guy; it’s no use giving him tough assignments.^\
Yes-man - подхалим, подпевала, лизоблюд - Victor tries to get ahead on his job by being a yes-man.^\
Yoke around someone's neck - ярмо на чьей-либо шее, обуза - I don’t want to live on my parents and be a yoke around their necks.^\
Zero hour - решающий момент - It was his zero hour.^\
Zero in on - сосредоточиться - We decided to zero in on grammar first.^\
Zero-sum game - выигрышно-проигрышная ситуация при которой, если выигрывает один, то неизменно проигрывает другой - It was a zero-sum game between the salesperson and the customer, and we couldn’t tell who would win and who would lose.^\
Zonk out - быстро заснуть, “вырубиться” - I couldn’t get a coherent word out of Stan as he had zonked out.^\
Zoom in on (someone or something) - электронное увеличение изображения во время фотографирования - The photographer zoomed in on the butterfly which was sitting on a flower.^\
"
;
sayings=sayings.split("^");
