#### английские идиомы

=====

![screenshot](../../res/engid.gif)

=====
* sayings.htm страничка
* sayings.js список фраз
* engidiom.user.js - content grabber - greasemonkey script
* zbg.css фон

*2014-05-12* раскраски : 1 -ночь 2 -утро 3 -день 4 - вечер

![run](/trespassersW/UserScripts/raw/master/htm/engidioms/sayings.htm)
